/* FROM FUTURE — cinematic hero engine.
   The scroll-driven treatment is deliberately scoped to the HERO ONLY.
   Everything below it is a static page: normal scrolling, no pinning,
   no scrubbed timelines, no scroll-jacking. */
(function () {
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);

  /* ---------- smooth scroll (easing only — never takes over position) ---------- */
  var lenis = null; window.__lenis = null;
  if (window.Lenis && !reduce) {
    lenis = window.__lenis = new Lenis({
      duration: 1.05,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
      smoothWheel: true
    });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
    document.documentElement.classList.add('lenis', 'lenis-smooth');
  }

  /* ================= HERO — intro ================= */
  gsap.timeline({ delay: .2 })
    .to('#act-hero .ln > i', { y: '0%', duration: 1.2, stagger: .1, ease: 'expo.out' })
    .to('#act-hero .hero-sub', { opacity: 1, duration: 1, ease: 'power2.out' }, '-=.7')
    .to('#act-hero .hero-act', { opacity: 1, duration: .85, ease: 'power2.out' }, '-=.65');

  /* ================= HERO — the one pinned moment on the site ================= */
  gsap.timeline({
    scrollTrigger: {
      trigger: '#act-hero', start: 'top top', end: 'bottom top',
      scrub: 1, pin: true, pinSpacing: false
    }
  })
    .to('#act-hero .film',      { scale: 1.28, opacity: .1, ease: 'none' }, 0)
    .to('#act-hero .hero-copy', { y: -130, opacity: 0, ease: 'none' }, 0)
    .to('#act-hero .hud',       { opacity: 0, ease: 'none' }, 0);

  var bar = document.querySelector('.hud .bar i');
  if (bar) ScrollTrigger.create({
    trigger: document.body, start: 'top top', end: 'bottom bottom',
    onUpdate: function (s) { bar.style.width = (s.progress * 100).toFixed(2) + '%'; }
  });

  /* ================= BELOW THE HERO — static ================= */
  /* One quiet fade-in per block, once. No pinning, no scrubbing, nothing
     that takes the scrollbar away from the visitor. */
  if (!reduce) {
    gsap.utils.toArray('[data-enter]').forEach(function (el) {
      gsap.fromTo(el, { y: 24, opacity: 0 }, {
        y: 0, opacity: 1, duration: .65, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 88%', once: true }
      });
    });
  }

  /* ---------- background film: keep playing, hide cleanly if it fails ---------- */
  document.querySelectorAll('video.film').forEach(function (v) {
    v.addEventListener('error', function () { v.setAttribute('data-dead', '1'); }, true);
    var src = v.querySelector('source');
    if (src) src.addEventListener('error', function () { v.setAttribute('data-dead', '1'); });
    setTimeout(function () { if (v.readyState === 0) v.setAttribute('data-dead', '1'); }, 6000);
    v.play().catch(function () {});
    ScrollTrigger.create({
      trigger: v.closest('section'), start: 'top bottom', end: 'bottom top',
      onEnter: function () { v.play().catch(function () {}); },
      onEnterBack: function () { v.play().catch(function () {}); },
      onLeave: function () { v.pause(); }, onLeaveBack: function () { v.pause(); }
    });
  });

  window.addEventListener('load', function () { ScrollTrigger.refresh(); });
})();
