/* FROM FUTURE — cinematic interactions */
(function(){
  var header=document.querySelector('.site-header');
  var onScroll=function(){header.classList.toggle('scrolled',window.scrollY>40)};
  window.addEventListener('scroll',onScroll,{passive:true});onScroll();

  /* nav dropdowns */
  document.querySelectorAll('.nav-links > li').forEach(function(li){
    var btn=li.querySelector('button');if(!btn)return;
    btn.addEventListener('click',function(e){e.stopPropagation();
      var was=li.classList.contains('open');
      document.querySelectorAll('.nav-links > li.open').forEach(function(o){o.classList.remove('open')});
      if(!was)li.classList.add('open');
    });
    li.addEventListener('mouseenter',function(){if(window.innerWidth>1080)li.classList.add('open')});
    li.addEventListener('mouseleave',function(){if(window.innerWidth>1080)li.classList.remove('open')});
  });
  document.addEventListener('click',function(){document.querySelectorAll('.nav-links > li.open').forEach(function(o){o.classList.remove('open')})});

  /* mobile burger */
  var burger=document.querySelector('.burger');
  if(burger)burger.addEventListener('click',function(){document.body.classList.toggle('mobile-open')});

  /* reveal on scroll */
  var io=new IntersectionObserver(function(entries){
    entries.forEach(function(en){if(en.isIntersecting){en.target.classList.add('on');io.unobserve(en.target)}});
  },{threshold:.14,rootMargin:'0px 0px -6% 0px'});
  document.querySelectorAll('.rv').forEach(function(el){io.observe(el)});

  /* counters */
  var cio=new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(!en.isIntersecting)return;cio.unobserve(en.target);
      var el=en.target,raw=el.getAttribute('data-count');
      // Only animate values that are ENTIRELY numeric (optional $ prefix / % suffix).
      // "24/7", "3-6", "5min" stay static — animating them garbles the text.
      var m=/^(\$?)([\d,]+(?:\.\d+)?)(%?)$/.test(raw)?raw.match(/^(\$?)([\d,]+(?:\.\d+)?)(%?)$/):null;
      if(!m){el.textContent=raw;return}
      var pre=m[1],target=parseFloat(m[2]),suf=m[3],t0=null;
      function frame(t){if(!t0)t0=t;var p=Math.min((t-t0)/1600,1);p=1-Math.pow(1-p,4);
        var v=target*p;el.textContent=pre+(target%1===0?Math.round(v):v.toFixed(1))+suf;
        if(p<1)requestAnimationFrame(frame)}
      requestAnimationFrame(frame);
    });
  },{threshold:.4});
  document.querySelectorAll('[data-count]').forEach(function(el){cio.observe(el)});

  /* accordions */
  document.querySelectorAll('.acc-item').forEach(function(item){
    var q=item.querySelector('.acc-q'),a=item.querySelector('.acc-a');
    q.addEventListener('click',function(){
      var open=item.classList.contains('open');
      item.parentElement.querySelectorAll('.acc-item.open').forEach(function(o){o.classList.remove('open');o.querySelector('.acc-a').style.maxHeight=null});
      if(!open){item.classList.add('open');a.style.maxHeight=a.scrollHeight+'px'}
    });
  });

  /* pricing tabs */
  var tabs=document.querySelectorAll('.tab[data-panel]');
  tabs.forEach(function(t){t.addEventListener('click',function(){
    tabs.forEach(function(x){x.classList.remove('active')});t.classList.add('active');
    document.querySelectorAll('.price-panel').forEach(function(p){p.style.display=(p.id===t.getAttribute('data-panel'))?'':'none'});
    var target=document.getElementById(t.getAttribute('data-panel'));if(target)target.scrollIntoView({behavior:'smooth',block:'nearest'});
  })});

  /* hero parallax drift */
  var heroBg=document.querySelector('.hero-bg');
  if(heroBg){window.addEventListener('scroll',function(){
    var y=window.scrollY;if(y<window.innerHeight*1.2)heroBg.style.transform='translateY('+y*0.28+'px)';
  },{passive:true})}

  /* cinematic hero: procedural nebula + particle drift (video takes over if hero.mp4 exists) */
  var cv=document.getElementById('ff-nebula');
  if(cv){
    var vid=document.querySelector('[data-ff-hero-video]');
    if(vid){vid.addEventListener('canplay',function(){vid.style.display='block';cv.style.display='none';vid.play().catch(function(){})});
      var src=vid.querySelector('source');fetch(src.src,{method:'HEAD'}).then(function(r){if(r.ok)vid.load()}).catch(function(){})}
    var ctx=cv.getContext('2d'),W,H,DPR=Math.min(window.devicePixelRatio||1,2);
    var P=[],ORBS=[],mx=.5,my=.4;
    function size(){W=cv.clientWidth;H=cv.clientHeight;cv.width=W*DPR;cv.height=H*DPR;ctx.setTransform(DPR,0,0,DPR,0,0)}
    size();window.addEventListener('resize',size);
    var N=Math.min(160,Math.floor(W*H/9000));
    for(var i=0;i<N;i++)P.push({x:Math.random(),y:Math.random(),z:.3+Math.random()*.7,s:Math.random()*1.6+.4,v:.00012+Math.random()*.00035,tw:Math.random()*6.28});
    for(var o=0;o<4;o++)ORBS.push({x:.15+Math.random()*.7,y:.15+Math.random()*.6,r:.28+Math.random()*.3,p:Math.random()*6.28,sp:.00018+Math.random()*.00025,hue:o%2?281:266});
    document.addEventListener('mousemove',function(e){mx=e.clientX/window.innerWidth;my=e.clientY/window.innerHeight},{passive:true});
    var reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    function draw(t){
      ctx.clearRect(0,0,W,H);
      ctx.globalCompositeOperation='lighter';
      for(var i=0;i<ORBS.length;i++){var ob=ORBS[i];
        var ox=(ob.x+Math.sin(t*ob.sp+ob.p)*.06+(mx-.5)*.03)*W;
        var oy=(ob.y+Math.cos(t*ob.sp*.8+ob.p)*.05+(my-.5)*.03)*H;
        var rr=ob.r*Math.min(W,H);
        var g=ctx.createRadialGradient(ox,oy,0,ox,oy,rr);
        g.addColorStop(0,'hsla('+ob.hue+',85%,60%,.14)');g.addColorStop(.5,'hsla('+ob.hue+',85%,55%,.05)');g.addColorStop(1,'hsla('+ob.hue+',85%,50%,0)');
        ctx.fillStyle=g;ctx.beginPath();ctx.arc(ox,oy,rr,0,6.28);ctx.fill()}
      for(var j=0;j<P.length;j++){var p=P[j];
        p.y-=p.v*p.z*(reduced?0:1);if(p.y<-.02)p.y=1.02;
        var px=(p.x+(mx-.5)*.02*p.z)*W,py=p.y*H;
        var a=(.25+.55*Math.abs(Math.sin(t*.001+p.tw)))*p.z;
        ctx.fillStyle='rgba(214,139,250,'+a.toFixed(3)+')';
        ctx.beginPath();ctx.arc(px,py,p.s*p.z,0,6.28);ctx.fill()}
      ctx.globalCompositeOperation='source-over';
      requestAnimationFrame(draw)}
    requestAnimationFrame(draw);
  }

  /* forms (placeholder handlers — wire to backend/Supabase; see README) */
  document.querySelectorAll('form[data-ff-form]').forEach(function(f){
    f.addEventListener('submit',function(e){e.preventDefault();
      var b=f.querySelector('button');var t=b.textContent;b.textContent='Thank you!';b.disabled=true;
      setTimeout(function(){b.textContent=t;b.disabled=false;f.reset()},3200);
    });
  });
})();
