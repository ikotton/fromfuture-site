#!/usr/bin/env python3
"""FROM FUTURE — static site generator. Run: python3 build.py  → outputs to dist/"""
import os, shutil, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
from base import DIST, ROOT
import services, pricing, misc, solutions, blog, themepreview

def main():
    if os.path.exists(DIST):
        shutil.rmtree(DIST)
    os.makedirs(DIST)
    shutil.copytree(ROOT + "/assets", DIST + "/assets")
    services.build()
    pricing.build()
    misc.build()
    solutions.build()
    blog.build()
    themepreview.build()
    # /contact did not exist on the old site (404) — redirect it to /connect to be safe
    os.makedirs(DIST + "/contact", exist_ok=True)
    with open(DIST + "/contact/index.html", "w") as f:
        f.write('<!DOCTYPE html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=/connect"><link rel="canonical" href="https://www.fromfuture.io/connect">')
    n = sum(len(files) for _, _, files in os.walk(DIST))
    pages = sum(1 for r, _, files in os.walk(DIST) if "index.html" in files)
    print(f"Built {pages} pages ({n} files) → dist/")

if __name__ == "__main__":
    main()
