/* FROM FUTURE — cinematic scroll engine (GSAP ScrollTrigger + Lenis) */
(function () {
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);

  /* ---------- smooth scroll ---------- */
  var lenis = null; window.__lenis = null;
  if (window.Lenis && !reduce) {
    lenis = window.__lenis = new Lenis({ duration: 1.15, easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); }, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
    document.documentElement.classList.add('lenis', 'lenis-smooth');
  }

  var mm = gsap.matchMedia();
  var DESK = '(min-width: 861px)';

  /* ================= ACT 1 · HERO ================= */
  var heroTl = gsap.timeline({ delay: .25 });
  heroTl.to('#act-hero .kicker', { opacity: 1, duration: .8, ease: 'power2.out' })
        .to('#act-hero .ln > i', { y: '0%', duration: 1.25, stagger: .105, ease: 'expo.out' }, '-=.5')
        .to('#act-hero .hero-sub', { opacity: 1, duration: 1, ease: 'power2.out' }, '-=.75')
        .to('#act-hero .hero-act', { opacity: 1, duration: .9, ease: 'power2.out' }, '-=.7');

  gsap.timeline({
    scrollTrigger: { trigger: '#act-hero', start: 'top top', end: 'bottom top', scrub: 1, pin: true, pinSpacing: false }
  })
  .to('#act-hero .film',     { scale: 1.32, opacity: .1, ease: 'none' }, 0)
  .to('#act-hero .hero-copy',{ y: -140, opacity: 0, ease: 'none' }, 0)
  .to('#act-hero .hud',      { opacity: 0, ease: 'none' }, 0)
  .to('#act-hero .veil.vig', { opacity: 1.6, ease: 'none' }, 0);

  /* progress rail */
  var bar = document.querySelector('.hud .bar i');
  if (bar) ScrollTrigger.create({
    trigger: document.body, start: 'top top', end: 'bottom bottom',
    onUpdate: function (s) { bar.style.width = (s.progress * 100).toFixed(2) + '%'; }
  });

  /* ================= ACT 2 · STATEMENTS ================= */
  var says = gsap.utils.toArray('#act-say .say');
  if (says.length) {
    var st = gsap.timeline({
      scrollTrigger: { trigger: '#act-say', start: 'top top', end: '+=' + (says.length * 90) + '%', scrub: .8, pin: true, anticipatePin: 1 }
    });
    says.forEach(function (el, i) {
      var span = el.querySelector('span');
      st.fromTo(el, { opacity: 0 }, { opacity: 1, duration: .34, ease: 'power2.out' }, i * .9)
        .fromTo(span, { y: 46, scale: .94, filter: 'blur(9px)' }, { y: 0, scale: 1, filter: 'blur(0px)', duration: .5, ease: 'power3.out' }, i * .9);
      if (i < says.length - 1) {
        st.to(el, { opacity: 0, duration: .3, ease: 'power2.in' }, i * .9 + .6)
          .to(span, { y: -40, scale: 1.05, filter: 'blur(9px)', duration: .3, ease: 'power2.in' }, i * .9 + .6);
      }
    });
    gsap.to('#act-say .film', {
      scale: 1.2, ease: 'none',
      scrollTrigger: { trigger: '#act-say', start: 'top bottom', end: 'bottom top', scrub: 1 }
    });
  }

  /* ================= ACT 3 · NUMBERS ================= */
  gsap.utils.toArray('.num-item').forEach(function (item) {
    var big = item.querySelector('.big');
    var copy = item.querySelector('p');
    var raw = big.getAttribute('data-to') || '';
    var m = raw.match(/^([^0-9-]*)(-?[\d.,]+)(.*)$/);
    gsap.timeline({ scrollTrigger: { trigger: item, start: 'top 82%', end: 'bottom 55%', scrub: 1 } })
      .fromTo(big, { y: 90, opacity: 0 }, { y: 0, opacity: 1, ease: 'none' }, 0)
      .fromTo(copy, { y: 50, opacity: 0 }, { y: 0, opacity: 1, ease: 'none' }, .12);
    if (m) {
      var pre = m[1], suf = m[3], target = parseFloat(m[2].replace(/,/g, '')), grouped = m[2].indexOf(',') > -1;
      var o = { v: 0 };
      gsap.to(o, {
        v: target, ease: 'none',
        scrollTrigger: { trigger: item, start: 'top 82%', end: 'bottom 62%', scrub: 1 },
        onUpdate: function () {
          var n = target % 1 === 0 ? Math.round(o.v) : o.v.toFixed(1);
          big.textContent = pre + (grouped ? Number(n).toLocaleString('en-US') : n) + suf;
        }
      });
    }
  });

  /* ================= ACT 4 · THE WIPE ================= */
  mm.add(DESK, function () {
    var tl = gsap.timeline({
      scrollTrigger: { trigger: '#act-wipe', start: 'top top', end: '+=200%', scrub: .7, pin: true, anticipatePin: 1 }
    });
    tl.fromTo('.wipe-new', { clipPath: 'inset(0 0 0 100%)' }, { clipPath: 'inset(0 0 0 0%)', ease: 'none' }, 0)
      .fromTo('.wipe-handle', { left: '100%' }, { left: '0%', ease: 'none' }, 0)
      .to('.wipe-handle', { opacity: 0, duration: .1 }, .92);
    return function () { gsap.set('.wipe-new', { clipPath: 'none' }); };
  });
  mm.add('(max-width: 860px)', function () { gsap.set('.wipe-new', { clipPath: 'none' }); });

  /* ================= ACT 5 · SERVICES RAIL ================= */
  var rail = document.querySelector('.rail');
  if (rail) {
    mm.add(DESK, function () {
      var dist = function () { return rail.scrollWidth - window.innerWidth + 80; };
      gsap.to(rail, {
        x: function () { return -dist(); }, ease: 'none',
        scrollTrigger: {
          trigger: '#act-rail', start: 'top top',
          end: function () { return '+=' + dist(); },
          scrub: .6, pin: true, anticipatePin: 1, invalidateOnRefresh: true
        }
      });
      gsap.utils.toArray('.card-x').forEach(function (c, i) {
        gsap.fromTo(c, { y: 46, opacity: .35 }, {
          y: 0, opacity: 1, ease: 'power2.out',
          scrollTrigger: { trigger: c, containerAnimation: gsap.getTweensOf(rail)[0], start: 'left 96%', end: 'left 62%', scrub: .5 }
        });
      });
    });
    mm.add('(max-width: 860px)', function () {
      gsap.utils.toArray('.card-x').forEach(function (c) {
        gsap.fromTo(c, { y: 40, opacity: 0 }, { y: 0, opacity: 1, duration: .7, ease: 'power2.out',
          scrollTrigger: { trigger: c, start: 'top 88%' } });
      });
    });
  }

  /* ================= ACT 6 · INDUSTRIES ================= */
  if (document.querySelector('#act-ind')) {
    var itl = gsap.timeline({
      scrollTrigger: { trigger: '#act-ind', start: 'top top', end: '+=160%', scrub: .8, pin: true, anticipatePin: 1 }
    });
    var cnt = document.querySelector('.ind-core .count');
    if (cnt) {
      var c = { v: 0 };
      itl.to(c, { v: 46, ease: 'none', onUpdate: function () { cnt.textContent = Math.round(c.v); } }, 0);
    }
    itl.fromTo('.ind-core .lbl', { opacity: 0, letterSpacing: '.7em' }, { opacity: 1, letterSpacing: '.3em', ease: 'none' }, 0)
       .fromTo('.streams', { opacity: 0 }, { opacity: .32, ease: 'none' }, 0);
    gsap.utils.toArray('.stream').forEach(function (s, i) {
      var dir = i % 2 ? 1 : -1;
      itl.fromTo(s, { x: dir * 380 }, { x: dir * -380, ease: 'none' }, 0);
    });
  }

  /* ================= ACT 7 · CLOSE ================= */
  gsap.timeline({ scrollTrigger: { trigger: '#act-close', start: 'top 78%', end: 'top 18%', scrub: .8 } })
    .to('#act-close .ln > i', { y: '0%', stagger: .14, ease: 'expo.out' }, 0)
    .fromTo('#act-close p', { y: 40, opacity: 0 }, { y: 0, opacity: 1, ease: 'none' }, .3)
    .fromTo('#act-close .close-act', { y: 34, opacity: 0 }, { y: 0, opacity: 1, ease: 'none' }, .45);
  gsap.to('#act-close .film', { scale: 1.18, ease: 'none',
    scrollTrigger: { trigger: '#act-close', start: 'top bottom', end: 'bottom top', scrub: 1 } });

  /* ---------- keep videos alive ---------- */
  document.querySelectorAll('video.film').forEach(function (v) {
    v.addEventListener('error', function () { v.setAttribute('data-dead', '1'); }, true);
    var src = v.querySelector('source');
    if (src) src.addEventListener('error', function () { v.setAttribute('data-dead', '1'); });
    setTimeout(function () { if (v.readyState === 0) v.setAttribute('data-dead', '1'); }, 6000);
    v.play().catch(function () {});
    ScrollTrigger.create({
      trigger: v.closest('section'), start: 'top bottom', end: 'bottom top',
      onEnter: function () { v.play().catch(function () {}); },
      onEnterBack: function () { v.play().catch(function () {}); },
      onLeave: function () { v.pause(); }, onLeaveBack: function () { v.pause(); }
    });
  });

  window.addEventListener('load', function () { ScrollTrigger.refresh(); });
})();
