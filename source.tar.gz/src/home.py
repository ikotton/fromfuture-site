from base import page, write_page, cards_grid, cta_section
import json, os

SERVICES_CARDS = [
 dict(title="Tap-To-Talk AI Agent", badge="Most Popular",
      desc="Instant voice interactions on your website. Natural conversations with customers using advanced AI technology.",
      features=["Low-latency voice responses","Website integration","Custom voice &amp; personality"], href="/services/tap-to-talk"),
 dict(title="PageSpeak",
      desc="Transform your written content into engaging audio with AI-powered voice technology. Increase accessibility and engagement.",
      features=["Natural-sounding voices","Multilingual support","Simple website integration"], href="/services/page-speak"),
 dict(title="AI SEO",
      desc="AI-driven SEO optimization to improve your website's visibility and ranking.",
      features=["Content optimization","Keyword analysis","Performance tracking"], href="/services/ai-seo"),
 dict(title="Phone AI Assistant",
      desc="AI-powered phone calls for appointments, inquiries, and customer support available 24/7.",
      features=["24/7 appointment scheduling","Noise-canceling technology","Calendar integration"], href="/services/phone-ai"),
 dict(title="Process Automation",
      desc="Streamline operations with AI-powered automation solutions.",
      features=["Workflow optimization","Task automation","Integration support"], href="/services/process-automation"),
 dict(title="AI Chatbot",
      desc="Intelligent chat solutions for instant customer support and engagement.",
      features=["24/7 availability","Multi-language support","Custom responses"], href="/services/chatbot"),
]

INDUSTRY_CARDS = [
 ("Legal Services","Manage client consultations efficiently, filter potential clients, and handle appointment scheduling automatically.","legal-services"),
 ("Real Estate","Schedule property viewings effectively and provide instant property information 24/7.","real-estate"),
 ("Dental Care","Simplify appointment booking processes and reduce staff workload with automated scheduling.","dental-care"),
 ("Restaurants","Enhance table utilization and never miss a reservation call with 24/7 automated booking assistance.","restaurants"),
 ("Interior Design","Transform consultation booking and project planning with intelligent voice assistance.","interior-designer"),
 ("Spa &amp; Beauty","Maximize appointment bookings and manage multiple service types efficiently.","spa"),
 ("Wedding Planning","Coordinate complex consultations and vendor scheduling with automated assistance.","wedding-planner"),
 ("Roofing Contractors","Handle emergency calls and weather-aware scheduling with intelligent routing and response.","roofing"),
 ("Massage Therapy","Streamline session bookings and handle after-hours scheduling with automated assistance.","massage-therapy"),
]

def industry_names():
    d = "/home/claude/fromfuture-site/content/solutions"
    names = []
    for fn in sorted(os.listdir(d)):
        with open(os.path.join(d, fn)) as f:
            j = json.load(f)
        n = j.get("h1","").replace("AI Voice Solutions for ","").strip() or fn[:-5].replace("-"," ").title()
        names.append((n, j["slug"]))
    return names

def build():
    hero = """
<section class="hero"><div class="hero-bg">
  <canvas id="ff-nebula" aria-hidden="true"></canvas>
  <!-- Optional cinematic film: drop assets/media/hero.mp4 into the repo and it takes over automatically -->
  <video autoplay muted loop playsinline data-ff-hero-video style="display:none"><source src="/assets/media/hero.mp4" type="video/mp4"></video>
</div>
<div class="wrap hero-inner">
  <div class="eyebrow rv on">Conversational AI Agents for Local Businesses</div>
  <h1 class="rv on"><span class="hline"><span>We Revolutionize</span></span><span class="hline"><span>Local Businesses with</span></span><span class="hline"><span class="grad-text">Artificial Intelligence</span></span></h1>
  <p class="lead rv rv-d1 on">Never miss a lead again. Our AI agents handle inquiries, book appointments, and support customers 24/7 &mdash; customized for your business.</p>
  <div class="demo-module rv rv-d2 on">
    <div style="flex:1"><label for="demo-sel">Hear a live AI agent</label>
      <select id="demo-sel" class="demo-select" aria-label="Choose demo">
        <option>From Future</option><option>Roofing</option><option>HVAC</option><option>Chiropractic</option>
      </select></div>
    <button class="play-btn" data-demo-play><span class="dot"></span> Play Demo</button>
  </div>
</div>
<div class="scroll-cue">Scroll</div>
</section>"""

    versus = """
<section><div class="wrap">
  <div class="section-head rv"><div class="eyebrow">The Shift</div>
    <h2>Traditional vs <span class="grad-text">AI-Powered</span></h2></div>
  <div class="versus rv">
    <div class="versus-col old"><h3>Traditional Business</h3>
      <div class="versus-item"><span class="vi">&times;</span>Limited by business hours and staff availability</div>
      <div class="versus-item"><span class="vi">&times;</span>Time-consuming manual processes</div>
      <div class="versus-item"><span class="vi">&times;</span>Missed opportunities and slow response times</div>
    </div>
    <div class="versus-col new"><h3>AI-Powered Business</h3>
      <div class="versus-item"><span class="vi">&check;</span>24/7 customer support and lead capture</div>
      <div class="versus-item"><span class="vi">&check;</span>Automated workflows and intelligent processing</div>
      <div class="versus-item"><span class="vi">&check;</span>Instant responses and intelligent lead qualification</div>
    </div>
  </div>
  <div class="center" style="margin-top:44px"><a class="btn btn-ghost rv" href="/services">Explore Our AI Solutions <span class="arrow">→</span></a></div>
</div></section>"""

    services = f"""
<section id="services"><div class="wrap">
  <div class="section-head rv"><div class="eyebrow">What We Build</div>
    <h2>AI Solutions That <span class="grad-text">Work While You Sleep</span></h2></div>
  {cards_grid(SERVICES_CARDS)}
  <div class="center" style="margin-top:54px">
    <a class="btn btn-primary rv" href="/connect">Schedule a Demo</a>
    <p class="rv" style="color:var(--grey-2);font-size:14px;margin-top:14px">See how our AI solutions can transform your business</p>
  </div>
</div></section>"""

    ind_cards = cards_grid([dict(title=t, desc=d, href=f"/solutions/voice-ai/{s}") for t,d,s in INDUSTRY_CARDS])
    names = industry_names()
    half = (len(names)+1)//2
    chips1 = "".join(f'<a class="chip" href="/solutions/voice-ai/{s}">{n}</a>' for n,s in names[:half])*2
    chips2 = "".join(f'<a class="chip" href="/solutions/voice-ai/{s}">{n}</a>' for n,s in names[half:])*2
    industries = f"""
<section style="padding-bottom:0"><div class="wrap">
  <div class="section-head rv"><div class="eyebrow">Industry Solutions</div>
    <h2>Built for <span class="grad-text">Your Industry</span></h2>
    <p class="lead" style="margin-top:18px">Discover how our AI voice assistants can transform customer service across different industries.</p></div>
  {ind_cards}
  <div class="center" style="margin:54px 0 70px">
    <a class="btn btn-ghost rv" href="/solutions/voice-ai/">Explore All Voice AI Industries <span class="arrow">→</span></a>
    <p class="rv" style="color:var(--grey-2);font-size:14px;margin-top:14px">Discover 45+ industry-specific AI voice solutions</p>
  </div>
</div>
<div class="marquee-band"><div class="marquee">{chips1}</div></div>
<div class="marquee-band" style="border-top:none"><div class="marquee rev">{chips2}</div></div>
</section>"""

    cta = f"""
<section><div class="wrap"><div class="cta-block rv"><div class="cta-grid"><div>
  <h2 class="grad-text">Ready to Transform Your Business?</h2>
  <p class="lead" style="margin-top:20px">Schedule a free strategy session with our AI experts to discover how voice AI can revolutionize your customer experience.</p>
  <ul class="cta-list">
    <li>Personalized AI strategy tailored to your business</li>
    <li>ROI analysis and implementation roadmap</li>
    <li>Live demo of our voice AI technology</li>
    <li>Expert insights on industry best practices</li>
  </ul></div>
  <div class="session-card"><h3>Book Your Strategy Session</h3>
    <p>30-minute consultation with our AI specialists</p>
    <a class="btn btn-primary" href="/connect">Schedule Now</a>
    <p class="micro">No commitment required</p>
  </div></div></div></div></section>"""

    body = hero + versus + services + industries + cta
    html = page("Conversational AI Agents For Local Businesses | From Future | FromFuture.io",
        "Transform your business with AI voice agents, chat agents, and automation solutions. Never miss a lead again with 24/7 AI-powered customer engagement.",
        body, canonical="https://www.fromfuture.io/")
    write_page("", html)
