from base import page, write_page
import json, os

CDN = "https://d8j0ntlcm91z4.cloudfront.net/user_3FS6yrfEeVAEm7ztxs55hRVp2sE/"
FILM = {
    "tunnel":  CDN + "hf_20260807_012130_a2971c33-9ef1-4730-99d6-bd46c27540be.mp4",
    "street":  CDN + "hf_20260807_014252_1ed13fdc-5f09-433f-8ea7-691bae5466cd.mp4",  # violet-graded, replaces warm original
    "wave":    CDN + "hf_20260807_012130_3d0eee99-12be-4bed-954d-343a233135f5.mp4",
    "monolith":CDN + "hf_20260807_012130_d3d4ef1e-9676-4280-830f-bac2dc3e5f6d.mp4",
    "plasma":  CDN + "hf_20260807_003956_b559fd01-3f6e-4599-8438-1d66669e0ddd.mp4",
}

HEAD = """<link rel="stylesheet" href="/assets/cinematic.css">
<link rel="preconnect" href="https://d8j0ntlcm91z4.cloudfront.net" crossorigin>"""

JS = """<script src="/assets/vendor/gsap.min.js"></script>
<script src="/assets/vendor/ScrollTrigger.min.js"></script>
<script src="/assets/vendor/lenis.min.js"></script>
<script src="/assets/cinematic.js"></script>"""

SERVICES = [
 ("Tap-To-Talk AI Agent", "Instant voice interactions on your website. Natural conversations with customers using advanced AI technology.", "/services/tap-to-talk", True),
 ("Phone AI Assistant", "AI-powered phone calls for appointments, inquiries, and customer support available 24/7.", "/services/phone-ai", False),
 ("AI Chatbot", "Intelligent chat solutions for instant customer support and engagement.", "/services/chatbot", False),
 ("PageSpeak", "Transform your written content into engaging audio with AI-powered voice technology. Increase accessibility and engagement.", "/services/page-speak", False),
 ("AI SEO", "AI-driven SEO optimization to improve your website's visibility and ranking.", "/services/ai-seo", False),
 ("Process Automation", "Streamline operations with AI-powered automation solutions.", "/services/process-automation", False),
]

NUMBERS = [
 ("62%",       "of calls to local businesses go unanswered. <b>Every single one is a customer who then called somebody else.</b>"),
 ("$126,000",  "is what the average small restaurant loses in a year to a phone nobody picks up."),
 ("78%",       "of callers hire whoever answers first. <b>Speed isn't part of the game. It is the game.</b>"),
 ("24/7",      "is how often your AI agent answers. No sick days, no voicemail, no hold music, no missed revenue."),
]

def industries():
    d = "/home/claude/fromfuture-site/content/solutions"
    out = []
    for fn in sorted(os.listdir(d)):
        with open(os.path.join(d, fn)) as f:
            j = json.load(f)
        n = (j.get("h1", "").split("|")[0].replace("AI Voice Solutions for", "").strip()
             or fn[:-5].replace("-", " ").title())
        out.append(n)
    return out


def lines(items):
    return "".join(f'<span class="ln"><i class="{c}">{t}</i></span>' for t, c in items)


def build():
    ind = industries()

    SLASH = '<span class="sl">/</span>'
    hero_h1 = lines([("We Clone Small", "dim"), ("Business Owners", ""),
                     ("To Run Their", ""), ("Front Office 24" + SLASH + "7", "lit")])
    hero = f"""
<section id="act-hero" class="stage" style="background-image:url(/assets/media/poster-tunnel.jpg)">
  <video class="film" autoplay muted loop playsinline preload="auto" poster="/assets/media/poster-tunnel.jpg">
    <source src="{FILM['tunnel']}" type="video/mp4"></video>
  <div class="veil grade"></div><div class="veil vig"></div><div class="veil scan"></div>
  <div class="hero-copy">
    <h1>{hero_h1}</h1>
    <p class="hero-sub">Stop being the bottleneck in your own business. We capture your exact voice, tone, and business rules into a custom AI engine that answers your phones, replies to DMs, handles emails, and books appointments on autopilot.</p>
    <div class="hero-act">
      <a class="btn btn-primary" href="/connect">Book a Systems Audit</a>
      <a class="btn btn-ghost" href="/services/tap-to-talk">Listen to Live Demo <span class="arrow">&rarr;</span></a>
    </div>
  </div>
  <div class="hud">
    <div class="left">Scroll<span class="bar"><i></i></span></div>
    <div class="right">Miami, FL &middot; fromfuture.io</div>
  </div>
</section>"""

    adv = """
<section id="act-adv" data-enter>
  <div class="adv-head">
    <div class="huge">The <span style="background:linear-gradient(96deg,#fff,var(--purple));-webkit-background-clip:text;background-clip:text;color:transparent">Unfair Advantage</span></div>
  </div>
  <div class="adv">
    <div class="adv-col old">
      <div class="adv-hd">Traditional Business Operations</div>
      <div class="adv-cell"><span class="m">&times;</span><div>
        <b>Missed Calls</b><p>Late-night &amp; weekend calls go to voicemail and die.</p></div></div>
      <div class="adv-cell"><span class="m">&times;</span><div>
        <b>Manual DM &amp; Email Replies</b><p>Leads sit for hours waiting for a human response.</p></div></div>
      <div class="adv-cell"><span class="m">&times;</span><div>
        <b>Staff Overwhelmed</b><p>Front-desk staff wastes time on repetitive intake logic.</p></div></div>
    </div>
    <div class="adv-col new">
      <div class="adv-hd">The Executive Clone System</div>
      <div class="adv-cell"><span class="m">&check;</span><div>
        <b>24<span class="sl">/</span>7 Live Voice</b><p>Your exact voice clone answers instantly, answers questions, and books appointments.</p></div></div>
      <div class="adv-cell"><span class="m">&check;</span><div>
        <b>Instant Multi-Channel Replies</b><p>AI handles DMs, reviews, and emails in your tone with human oversight.</p></div></div>
      <div class="adv-cell"><span class="m">&check;</span><div>
        <b>Automated Intake</b><p>Routine scheduling and qualification happen on autopilot so staff focuses on high-ticket tasks.</p></div></div>
    </div>
  </div>
</section>"""

    say = f"""
<section id="act-say" class="stage" style="background-image:url(/assets/media/poster-street.jpg)">
  <video class="film" autoplay muted loop playsinline preload="auto" poster="/assets/media/poster-street.jpg" style="opacity:.32">
    <source src="{FILM['street']}" type="video/mp4"></video>
  <div class="veil vig"></div>
  <div class="say-wrap">
    <div class="say"><span>Your phone rang.</span></div>
    <div class="say red"><span>Nobody answered.</span></div>
    <div class="say"><span>They called<br>someone else.</span></div>
    <div class="say win"><span>Not anymore.</span></div>
  </div>
</section>"""

    nums = "".join(
        f'<div class="num-item"><div class="big" data-to="{v}">{v}</div><p>{t}</p></div>'
        for v, t in NUMBERS)
    numbers = f"""
<section id="act-num">
  <video class="film" autoplay muted loop playsinline preload="auto" poster="/assets/media/poster-plasma.jpg" style="opacity:.14">
    <source src="{FILM['plasma']}" type="video/mp4"></video>
  <div class="veil vig"></div>
  <div class="num-row" style="position:relative;z-index:3">
    <div style="margin-bottom:-30px"><div class="kicker">The Cost of Silence</div></div>
    {nums}
  </div>
</section>"""

    wipe = """
<section id="act-wipe" class="stage">
  <div class="wipe-pane wipe-old"><div class="inner">
    <h2>Traditional<br>Business</h2>
    <ul class="wipe-list">
      <li><span class="m">&times;</span>Limited by business hours and staff availability</li>
      <li><span class="m">&times;</span>Time-consuming manual processes</li>
      <li><span class="m">&times;</span>Missed opportunities and slow response times</li>
    </ul></div></div>
  <div class="wipe-pane wipe-new"><div class="inner">
    <h2>AI-Powered<br>Business</h2>
    <ul class="wipe-list">
      <li><span class="m">&check;</span>24/7 customer support and lead capture</li>
      <li><span class="m">&check;</span>Automated workflows and intelligent processing</li>
      <li><span class="m">&check;</span>Instant responses and intelligent lead qualification</li>
    </ul></div></div>
  <div class="wipe-handle"></div>
</section>"""

    cards = "".join(
        f"""<a class="card-x{' tag' if pop else ''}" href="{href}">
          <div class="no">{i+1:02d}</div><h3>{t}</h3><p>{d}</p>
          <span class="go">Learn more <span class="arrow">&rarr;</span></span></a>"""
        for i, (t, d, href, pop) in enumerate(SERVICES))
    rail = f"""
<section id="act-rail" class="stage" style="justify-content:flex-start">
  <div class="rail-head" data-enter><div class="kicker">What We Build</div>
    <div class="huge">Comprehensive <span style="background:linear-gradient(96deg,#fff,var(--purple));-webkit-background-clip:text;background-clip:text;color:transparent">AI Solutions</span></div></div>
  <div class="rail" style="margin-top:60px">{cards}
    <a class="card-x" href="/services" style="background:linear-gradient(155deg,rgba(193,84,248,.2),rgba(193,84,248,.04));border-color:rgba(193,84,248,.45)">
      <div class="no">&rarr;</div><h3>See every<br>service</h3><p>Full breakdown of what we build, how it integrates, and what it costs.</p>
      <span class="go">All services <span class="arrow">&rarr;</span></span></a>
  </div>
</section>"""

    per = (len(ind) + 3) // 4
    streams = ""
    for r in range(4):
        chunk = ind[r * per:(r + 1) * per] or ind[:8]
        items = "".join(f'<b class="{"hot" if (i + r) % 4 == 0 else ""}">{n}</b>' for i, n in enumerate(chunk * 3))
        streams += f'<div class="stream">{items}</div>'
    industries_sec = f"""
<section id="act-ind" class="stage" style="background-image:url(/assets/media/poster-wave.jpg)">
  <video class="film" autoplay muted loop playsinline preload="auto" poster="/assets/media/poster-wave.jpg" style="opacity:.18">
    <source src="{FILM['wave']}" type="video/mp4"></video>
  <div class="streams">{streams}</div>
  <div class="veil vig"></div>
  <div class="ind-core" data-enter>
    <div class="kicker" style="margin-bottom:18px">Industry Solutions</div>
    <div class="count">46</div>
    <div class="lbl">Industries Served</div>
    <div style="margin-top:38px"><a class="btn btn-ghost" href="/solutions/voice-ai/">Find Yours <span class="arrow">&rarr;</span></a></div>
  </div>
</section>"""

    close = f"""
<section id="act-close" class="stage cine" style="background-image:url(/assets/media/poster-monolith.jpg)">
  <video class="film" autoplay muted loop playsinline preload="auto" poster="/assets/media/poster-monolith.jpg" style="opacity:.4">
    <source src="{FILM['monolith']}" type="video/mp4"></video>
  <div class="veil vig"></div>
  <div class="close-core">
    <div class="kicker" style="margin-bottom:24px">Your Move</div>
    <div class="mega">{lines([("Ready to","dim"),("Transform","" ),("Your Business?","lit")])}</div>
    <p>Thirty minutes with our AI specialists. A strategy built for your business, an ROI model with your numbers in it, and a live demo. No commitment.</p>
    <div class="close-act">
      <a class="btn btn-primary" href="/connect">Book Your Strategy Session</a>
      <a class="btn btn-ghost" href="/pricing">See Pricing</a>
    </div>
  </div>
</section>"""

    body = f'<div class="cine">{hero}<div class="below-hero">{adv}{rail}{industries_sec}{close}</div></div>'
    write_page("", page(
        "Conversational AI Agents For Local Businesses | From Future | FromFuture.io",
        "Never miss a lead again. AI voice agents that answer every call, book every appointment, and work 24/7 — customized for your business.",
        body, canonical="https://www.fromfuture.io/", extra_head=HEAD, extra_js=JS))
