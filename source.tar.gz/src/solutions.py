from base import page, write_page, page_hero, cards_grid
from services import sec
import json, os

ROOT = "/home/claude/fromfuture-site"
SOLDIR = ROOT + "/content/solutions"

FEATURED = [
 ("Legal Services","Manage client consultations efficiently, filter potential clients, and handle appointment scheduling automatically.","legal-services"),
 ("Real Estate","Schedule property viewings effectively and provide instant property information 24/7.","real-estate"),
 ("Dental Care","Simplify appointment booking processes and reduce staff workload with automated scheduling.","dental-care"),
 ("Restaurants","Enhance table utilization and never miss a reservation call with 24/7 automated booking assistance.","restaurants"),
 ("Interior Design","Transform consultation booking and project planning with intelligent voice assistance.","interior-designer"),
 ("Spa &amp; Beauty","Maximize appointment bookings and manage multiple service types efficiently.","spa"),
 ("Wedding Planning","Coordinate complex consultations and vendor scheduling with automated assistance.","wedding-planner"),
 ("Roofing Contractors","Handle emergency calls and weather-aware scheduling with intelligent routing and response.","roofing"),
]

def load_all():
    out = []
    for fn in sorted(os.listdir(SOLDIR)):
        with open(os.path.join(SOLDIR, fn)) as f:
            out.append(json.load(f))
    return out

def clean_h1(j):
    h1 = (j.get("h1") or "").split("|")[0].strip()
    if not h1:
        h1 = "AI Voice Solutions for " + j["slug"].replace("-"," ").title()
    return h1

def display_name(j):
    return clean_h1(j).replace("AI Voice Solutions for ","").strip()

def build_page(j):
    slug = j["slug"]
    h1 = clean_h1(j)
    name = display_name(j)
    uc_name = (j.get("usecase_section_name") or name).split("|")[0].strip()
    ctas = '<a class="btn btn-primary" href="/connect">Try Voice AI Demo</a><a class="btn btn-ghost" href="/connect">Schedule Consultation</a>'
    disp = h1.replace("AI Voice Solutions for ", 'AI Voice Solutions for <span class="grad-text">') + "</span>" if "AI Voice Solutions for" in h1 else f'<span class="grad-text">{h1}</span>'

    body = page_hero("Voice AI &middot; Industry Solutions", disp, j.get("hero_sub",""), ctas,
        extra=f'<p class="rv rv-d3" style="color:var(--grey);max-width:720px;margin-top:30px">{j.get("intro","")}</p>')

    uc_cards = []
    for u in j.get("use_cases", []):
        ex = f'<p style="font-size:14px;margin-top:14px"><span style="font-family:var(--display);font-size:9.5px;letter-spacing:.2em;text-transform:uppercase;color:var(--tint)">Real-World Example</span><br>{u.get("example","")}</p>' if u.get("example") else ""
        uc_cards.append(dict(title=u.get("title",""), stat=u.get("stat",""), desc=(u.get("description","") or "") ))
    grid = []
    for i,(c,u) in enumerate(zip(uc_cards, j.get("use_cases", []))):
        ex = u.get("example","")
        exh = f'<div style="border-top:1px solid var(--line-soft);margin-top:18px;padding-top:14px"><div style="font-family:var(--display);font-size:9.5px;letter-spacing:.2em;text-transform:uppercase;color:var(--tint);margin-bottom:6px">Real-World Example</div><p style="font-size:14px">{ex}</p></div>' if ex else ""
        stat = f'<div style="font-family:var(--display);font-weight:700;color:var(--tint);font-size:13px;letter-spacing:.06em;margin-bottom:10px">{c["stat"]}</div>' if c.get("stat") else ""
        grid.append(f'<div class="card rv rv-d{i%3}"><h3>{c["title"]}</h3>{stat}<p>{c["desc"]}</p>{exh}</div>')
    body += sec("Use Cases", f'Use Cases for <span class="grad-text">{uc_name}</span>', "", f'<div class="grid-3">{"".join(grid)}</div>')

    fcards = [dict(title=f.get("title",""), desc=f.get("description",""), features=[b for b in f.get("bullets",[]) if b]) for f in j.get("features",[])]
    body += sec("Key Features", 'Key <span class="grad-text">Features</span>', "", cards_grid(fcards))

    bcards = [dict(title=b.get("title",""), desc=b.get("description",""), features=[x for x in b.get("bullets",[]) if x]) for b in j.get("benefits",[])]
    body += sec("Key Benefits", 'Key <span class="grad-text">Benefits</span>', "", cards_grid(bcards))

    body += f"""<section><div class="wrap"><div class="cta-block rv"><div class="cta-grid"><div>
      <h2 class="grad-text">Ready to Transform Your Business?</h2>
      <p class="lead" style="margin-top:20px">Experience the power of AI voice technology firsthand. Try our demo or schedule a consultation to learn how we can customize our solution for your specific needs.</p></div>
      <div class="session-card"><h3>See It Live</h3><p>Try the demo or book a consultation</p>
      <a class="btn btn-primary" href="/connect" style="margin-bottom:12px">Try Voice AI Demo</a><br>
      <a class="btn btn-ghost" href="/connect">Schedule Consultation</a></div></div></div></div></section>"""

    title = (j.get("title_tag") or f"{h1} | From Future").strip()
    desc = (j.get("meta_description") or j.get("hero_sub","")).strip()
    write_page(f"solutions/voice-ai/{slug}", page(title, desc, body,
        canonical=f"https://www.fromfuture.io/solutions/voice-ai/{slug}"))

def build_index(all_pages):
    feat = cards_grid([dict(title=t, desc=d, href=f"/solutions/voice-ai/{s}") for t,d,s in FEATURED], cols=2)
    featured_slugs = {s for _,_,s in FEATURED}
    rest = []
    for j in all_pages:
        rest.append(dict(title=display_name(j), desc=(j.get("hero_sub") or ""), href=f"/solutions/voice-ai/{j['slug']}"))
    rest_html = cards_grid(rest, cols=3)
    body = page_hero("Voice AI Solutions", 'AI Voice Solutions for <span class="grad-text">Every Industry</span>',
        "Transform your customer service with intelligent voice assistants tailored to your industry's unique needs.",
        '<a class="btn btn-primary" href="/connect">Get Started</a>')
    body += sec("Featured","Featured Industry <span class='grad-text'>Solutions</span>","", feat)
    body += sec("All Industries","Explore All <span class='grad-text'>Industries</span>", f"{len(all_pages)} industry-specific AI voice solutions", rest_html)
    body += f"""<section><div class="wrap"><div class="cta-block rv center" style="text-align:center"><div>
      <h2 class="grad-text">Ready to Transform Your Industry?</h2>
      <p class="lead" style="margin:20px auto 34px">Try our demo or schedule a consultation to learn how we can customize our solution for your specific needs.</p>
      <a class="btn btn-primary" href="/connect">Get Started</a></div></div></div></section>"""
    write_page("solutions/voice-ai", page("AI Voice Solutions for Every Industry | From Future",
        "Discover 45+ industry-specific AI voice solutions. Transform your customer service with intelligent voice assistants tailored to your industry's unique needs.",
        body, canonical="https://www.fromfuture.io/solutions/voice-ai/"))

def build():
    pages = load_all()
    for j in pages:
        build_page(j)
    build_index(pages)
