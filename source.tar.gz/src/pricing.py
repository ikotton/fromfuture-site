from base import page, write_page, page_hero, cta_section
from services import sec, stats, accordion

def price_card(title, sub, amount, amount_note, subnote, maint, usage, feats, cta_label, cta_href, badge=None, delay=0):
    b = f'<div class="badge">{badge}</div>' if badge else ""
    m = f'<div class="maint">{maint}</div>' if maint else ""
    fl = "".join(f"<li>{f}</li>" for f in feats)
    return f"""<div class="card price-card rv rv-d{delay}">{b}
      <h3>{title}</h3><p>{sub}</p>
      <div class="amount">{amount} <small>{amount_note}</small></div>
      <div class="subnote">{subnote}</div>{m}
      <div class="usage-note">{usage}</div>
      <ul>{fl}</ul>
      <a class="btn btn-primary" href="{cta_href}">{cta_label}</a></div>"""

def build():
    hero = page_hero("Pricing", 'Transparent &amp; <span class="grad-text">Flexible Pricing</span>',
        "We believe in transparent pricing with no hidden fees. Our AI solutions are tailored to your specific needs, with packages that scale as your business grows.",
        extra="""<div class="tabs rv rv-d2">
          <button class="tab active" data-panel="voice-ai">Voice AI</button>
          <button class="tab" data-panel="conversational-ai">Contextual AI</button>
          <button class="tab" data-panel="business-ai">Business AI</button>
        </div>
        <p class="rv rv-d3" style="color:var(--grey-2);font-size:14px">Need help? <a href="/connect" style="color:var(--tint)">Schedule a consultation</a></p>""")

    voice = f"""<section id="voice-ai" class="price-panel" style="padding-top:20px"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Voice AI Solutions</div><h2>Voice <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("Tap-to-Talk AI","Voice AI assistant for your website","$499","setup (starting at)","Includes 2 free revision rounds","+$299 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with conversation time.",
        ["Custom voice &amp; personality","Website integration","Knowledge base creation","500 minutes included monthly","Lead qualification"],"Get Custom Quote","/connect",badge="Most Popular")}
      {price_card("Phone AI Assistant","Voice AI for phone calls and appointments","$499","setup (starting at)","Includes 2 free revision rounds","+$349 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with call time.",
        ["Dedicated phone number","Custom voice &amp; personality","Knowledge base creation","500 minutes included monthly","Appointment scheduling"],"Get Custom Quote","/connect",delay=1)}
      {price_card("PageSpeak","Transform written content into engaging audio","$499","setup (one-time)","Includes initial content setup","","Content Credits: Pay once per page for conversion. Unlimited listening after conversion.",
        ["Full website integration","Custom widget styling","One-time conversion fee per page","Unlimited listening after conversion","Volume discounts for larger sites","Optional voice cloning ($299)"],"Purchase Now","https://portal.fromfuture.io/order/page-speak",delay=2)}
      </div></div></section>"""

    conv = f"""<section id="conversational-ai" class="price-panel" style="padding-top:20px;display:none"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Contextual AI</div><h2>Contextual <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("AI Chatbots","24/7 intelligent chat solutions for customer support","$299","setup (starting at)","Includes 2 free revision rounds","+$99 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with conversation time.",
        ["Custom voice &amp; personality","Website integration","Knowledge base creation","500 minutes included monthly","Lead qualification"],"Get Custom Quote","/connect")}
      </div></div></section>"""

    biz = f"""<section id="business-ai" class="price-panel" style="padding-top:20px;display:none"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Business AI Solutions</div><h2>Business <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("Business AI","Automate business processes and gain insights","$999","setup (starting at)","Includes 2 free revision rounds","+$499 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with usage volume.",
        ["Custom AI models","Data integration","Automated insights","Process automation","Predictive analytics"],"Get Custom Quote","/connect")}
      </div></div></section>"""

    # NOTE: FAQ answers reconstructed from site facts — original answers load via JS. Flag for owner review.
    faq = accordion([
      ("Why don't you have fixed pricing for all services?","Every business is different. Our AI solutions are customized to your specific needs &mdash; knowledge base size, call volume, and integrations all affect scope &mdash; so we quote a starting setup price and tailor the final package to your business."),
      ("What's included in the setup fee?","Setup includes building and customizing your AI agent &mdash; voice and personality, knowledge base creation, website or phone integration, and testing &mdash; plus 2 free revision rounds."),
      ("Do you offer discounts for bundling multiple services?","Yes. When you combine multiple AI solutions, we build a custom bundle at a preferred rate. Schedule a consultation and we'll put together the right package."),
      ("Is there a contract or minimum commitment?","No long-term contracts. Monthly maintenance is optional, and usage credits mean you only pay for what you use."),
      ("Do you offer white-label pricing for agencies?","Yes. From Future's solutions are available white-label for digital marketing agencies. Contact us for agency pricing and partner terms."),
      ("How does Voice AI pricing work with setup, maintenance, and usage?","You pay a one-time setup fee to build your agent, an optional monthly maintenance fee to keep it tuned and updated, and usage credits that scale with conversation or call time &mdash; with 500 minutes included monthly."),
      ("What's the difference between Tap-to-Talk and Phone AI?","Tap-to-Talk lives on your website &mdash; visitors tap and speak with your AI in the browser. Phone AI answers a dedicated phone number, handling real calls, appointments, and lead qualification 24/7."),
    ])
    faq_sec = sec("FAQ","Frequently Asked <span class='grad-text'>Questions</span>","",
        faq + '<div class="center" style="margin-top:36px"><p style="color:var(--grey);margin-bottom:18px">Still have questions about our pricing? We\'re here to help.</p><a class="btn btn-primary" href="/connect" style="margin-right:12px">Schedule a Consultation</a><a class="btn btn-ghost" href="/connect">Contact Sales</a></div>')

    guarantee = sec("Our Promise","Our AI Performance <span class='grad-text'>Guarantee</span>",
        "We're confident in our AI solutions. If you don't see measurable improvements in the first 30 days, we'll extend your service for free until you do.",
        stats([("80%","Average cost reduction"),("24/7","Always-on service"),("30+","Days ROI timeline")]))

    body = hero + voice + conv + biz + faq_sec + guarantee
    body += cta_section("Ready to transform your business with AI?",
        "Book your free strategy session today and discover how our AI solutions can revolutionize your customer experience and operations.",
        "Schedule a Strategy Session", btn2=("Explore Services","/services"))
    write_page("pricing", page("Pricing | From Future AI Solutions",
        "Transparent pricing for AI voice agents, chatbots, and automation solutions. Find the perfect package for your business with flexible, scalable options.",
        body, canonical="https://www.fromfuture.io/pricing"))
