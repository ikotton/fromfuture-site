from base import page, write_page, page_hero, cta_section
from services import sec, stats, accordion

def price_card(title, sub, amount, amount_note, subnote, maint, usage, feats, cta_label, cta_href, badge=None, delay=0):
    b = f'<div class="badge">{badge}</div>' if badge else ""
    m = f'<div class="maint">{maint}</div>' if maint else ""
    fl = "".join(f"<li>{f}</li>" for f in feats)
    return f"""<div class="card price-card rv rv-d{delay}">{b}
      <h3>{title}</h3><p>{sub}</p>
      <div class="amount">{amount} <small>{amount_note}</small></div>
      <div class="subnote">{subnote}</div>{m}
      <div class="usage-note">{usage}</div>
      <ul>{fl}</ul>
      <a class="btn btn-primary" href="{cta_href}">{cta_label}</a></div>"""

def build():
    hero = page_hero("Pricing", 'Transparent &amp; <span class="grad-text">Flexible Pricing</span>',
        "We believe in transparent pricing with no hidden fees. Our AI solutions are tailored to your specific needs, with packages that scale as your business grows.",
        extra="""<div class="tabs rv rv-d2">
          <button class="tab active" data-panel="voice-ai">Voice AI</button>
          <button class="tab" data-panel="conversational-ai">Contextual AI</button>
          <button class="tab" data-panel="business-ai">Business AI</button>
        </div>
        <p class="rv rv-d3" style="color:var(--grey-2);font-size:14px">Need help? <a href="/connect" style="color:var(--tint)">Schedule a consultation</a></p>""")

    voice = f"""<section id="voice-ai" class="price-panel" style="padding-top:20px"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Voice AI Solutions</div><h2>Voice <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("Tap-to-Talk AI","Voice AI assistant for your website","$499","setup (starting at)","Includes 2 free revision rounds","+$299 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with conversation time.",
        ["Custom voice &amp; personality","Website integration","Knowledge base creation","500 minutes included monthly","Lead qualification"],"Get Custom Quote","/connect",badge="Most Popular")}
      {price_card("Phone AI Assistant","Voice AI for phone calls and appointments","$499","setup (starting at)","Includes 2 free revision rounds","+$349 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with call time.",
        ["Dedicated phone number","Custom voice &amp; personality","Knowledge base creation","500 minutes included monthly","Appointment scheduling"],"Get Custom Quote","/connect",delay=1)}
      {price_card("PageSpeak","Transform written content into engaging audio","$499","setup (one-time)","Includes initial content setup","","Content Credits: Pay once per page for conversion. Unlimited listening after conversion.",
        ["Full website integration","Custom widget styling","One-time conversion fee per page","Unlimited listening after conversion","Volume discounts for larger sites","Optional voice cloning ($299)"],"Purchase Now","https://portal.fromfuture.io/order/page-speak",delay=2)}
      </div></div></section>"""

    conv = f"""<section id="conversational-ai" class="price-panel" style="padding-top:20px;display:none"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Contextual AI</div><h2>Contextual <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("AI Chatbots","24/7 intelligent chat solutions for customer support","$299","setup (starting at)","Includes 2 free revision rounds","+$99 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with conversation time.",
        ["Custom voice &amp; personality","Website integration","Knowledge base creation","500 minutes included monthly","Lead qualification"],"Get Custom Quote","/connect")}
      </div></div></section>"""

    biz = f"""<section id="business-ai" class="price-panel" style="padding-top:20px;display:none"><div class="wrap">
      <div class="section-head rv"><div class="eyebrow">Business AI Solutions</div><h2>Business <span class="grad-text">AI</span></h2></div>
      <div class="grid-3">
      {price_card("Business AI","Automate business processes and gain insights","$999","setup (starting at)","Includes 2 free revision rounds","+$499 /mo maintenance (optional)","Usage Credits: Pay only for what you use. Pricing scales with usage volume.",
        ["Custom AI models","Data integration","Automated insights","Process automation","Predictive analytics"],"Get Custom Quote","/connect")}
      </div></div></section>"""

    # FAQ answers extracted verbatim from the live fromfuture.io/pricing (JS-rendered)
    faq = accordion([
      ("Why don't you have fixed pricing for all services?","AI solutions need to be tailored to each business's unique needs. Factors like integration complexity, customization level, and usage volume affect pricing. Our 'starting at' prices represent the base package, and we provide custom quotes to ensure you only pay for what you need."),
      ("What's included in the setup fee?","Our setup fee covers the initial configuration of your AI solution, including knowledge base creation, voice customization, integration with your existing systems, and initial training. This ensures your AI solution is perfectly tailored to your business from day one."),
      ("Do you offer discounts for bundling multiple services?","Yes! Many of our clients achieve the best results by combining multiple AI solutions. We offer package discounts when you implement more than one service, which we can discuss during your consultation."),
      ("Is there a contract or minimum commitment?","Our standard agreements are month-to-month with no long-term commitment required. We also offer discounted rates for annual commitments. You can upgrade, downgrade, or cancel with 30 days' notice."),
      ("Do you offer white-label pricing for agencies?","Yes, we offer special pricing for marketing agencies looking to white-label our AI solutions. Our agency partners receive wholesale pricing, co-branded marketing materials, and dedicated support. Contact us for our agency partner program details."),
      ("How does Voice AI pricing work with setup, maintenance, and usage?","Our Voice AI pricing has three components: 1) Initial setup fee (starting at $499) which includes customization, knowledge base creation, and 2 free revision rounds, 2) Optional monthly maintenance (starting at $299) for ongoing updates and optimizations, and 3) Usage-based credits that only charge you for actual conversation time. This structure ensures you only pay for what you need, and the exact pricing scales with the complexity of your implementation and usage volume."),
      ("What's the difference between Tap-to-Talk and Phone AI?","Tap-to-Talk is a website-embedded voice assistant that visitors interact with by tapping an icon and speaking directly through their device. It's ideal for websites and has lower latency. Phone AI provides a dedicated phone number that connects callers to an AI assistant, making it perfect for handling calls, scheduling appointments, and environments with background noise as it leverages phone audio processing."),
    ])
    faq_sec = sec("FAQ","Frequently Asked <span class='grad-text'>Questions</span>","",
        faq + '<div class="center" style="margin-top:36px"><p style="color:var(--grey);margin-bottom:18px">Still have questions about our pricing? We\'re here to help.</p><a class="btn btn-primary" href="/connect" style="margin-right:12px">Schedule a Consultation</a><a class="btn btn-ghost" href="/connect">Contact Sales</a></div>')

    guarantee = sec("Our Promise","Our AI Performance <span class='grad-text'>Guarantee</span>",
        "We're confident in our AI solutions. If you don't see measurable improvements in the first 30 days, we'll extend your service for free until you do.",
        stats([("80%","Average cost reduction"),("24/7","Always-on service"),("30+","Days ROI timeline")]))

    body = hero + voice + conv + biz + faq_sec + guarantee
    body += cta_section("Ready to transform your business with AI?",
        "Book your free strategy session today and discover how our AI solutions can revolutionize your customer experience and operations.",
        "Schedule a Strategy Session", btn2=("Explore Services","/services"))
    write_page("pricing", page("Pricing | From Future AI Solutions",
        "Transparent pricing for AI voice agents, chatbots, and automation solutions. Find the perfect package for your business with flexible, scalable options.",
        body, canonical="https://www.fromfuture.io/pricing"))
