from base import page, write_page, page_hero, cards_grid, cta_section

def sec(eyebrow, h2, lead, inner, id=""):
    idattr = f' id="{id}"' if id else ""
    lead_html = f'<p class="lead" style="margin-top:18px">{lead}</p>' if lead else ""
    return f"""<section{idattr}><div class="wrap">
    <div class="section-head rv"><div class="eyebrow">{eyebrow}</div><h2>{h2}</h2>{lead_html}</div>
    {inner}</div></section>"""

def stats(items):
    inner = "".join(f'<div class="stat rv"><div class="num" data-count="{n}">{n}</div><div class="lbl">{l}</div></div>' for n,l in items)
    return f'<div class="stats-row">{inner}</div>'

def steps(items):
    inner = "".join(f'<div class="step rv"><h3>{t}</h3><p style="color:var(--grey);margin-top:12px;font-size:15px">{d}</p></div>' for t,d in items)
    return f'<div class="steps">{inner}</div>'

def accordion(qas):
    out = ['<div class="acc rv">']
    for q,a in qas:
        out.append(f'<div class="acc-item"><button class="acc-q">{q}<span class="plus">+</span></button><div class="acc-a"><p>{a}</p></div></div>')
    out.append("</div>")
    return "".join(out)

# ---------------- services index ----------------
def build_index():
    voice = cards_grid([
      dict(title="Tap-to-Talk Voice AI", desc="Add instant voice interactions to your website. Natural conversations with customers using advanced AI technology.",
           features=["Natural voice interactions","Instant responses","Multi-language support","Custom voice &amp; personality"], href="/services/tap-to-talk"),
      dict(title="Phone AI Assistant", desc="AI-powered phone system that handles calls, schedules appointments, and qualifies leads 24/7.",
           features=["24/7 availability","Automated scheduling","Lead qualification","Seamless handoff to staff"], href="/services/phone-ai"),
      dict(title="PageSpeak", desc="Transform your written content into engaging audio with AI-powered text-to-speech technology.",
           features=["Instant audio conversion","Multi-language support","Custom voice options","Simple integration"], href="/services/page-speak"),
    ])
    conv = cards_grid([
      dict(title="AI Chatbot", desc="Intelligent chatbots that understand context and provide personalized customer support.",
           features=["Context-aware responses","Multi-channel support","Custom workflows","Human handoff options"], href="/services/chatbot"),
    ], cols=3)
    biz = cards_grid([
      dict(title="AI Search Optimization", desc="Optimize your business for AI-powered search engines and stay ahead of the competition.",
           features=["AI search indexing","Content optimization","Competitive analysis","Performance tracking"], href="/services/ai-seo"),
      dict(title="Process Automation", desc="Streamline operations and eliminate repetitive tasks with AI-powered automation.",
           features=["Custom workflows","Integration support","Error reduction","Efficiency analytics"], href="/services/process-automation"),
    ])
    body = page_hero("Our Services", 'Comprehensive <span class="grad-text">AI Solutions</span>',
        "Transform your business with our suite of AI-powered services. From voice interactions to process automation, we've got everything you need to stay ahead.",
        '<a class="btn btn-primary" href="/connect">Schedule a consultation</a>')
    body += sec("Voice AI Solutions","Voice AI <span class='grad-text'>Solutions</span>","Transform how customers interact with your business through natural voice conversations.", voice, id="voice-ai")
    body += sec("Conversational AI","Conversational AI <span class='grad-text'>Solutions</span>","Engage customers with intelligent chat experiences that drive results.", conv, id="conversational-ai")
    body += sec("Business AI","Business AI <span class='grad-text'>Solutions</span>","Automate business processes and gain insights with AI.", biz, id="business-ai")
    body += cta_section()
    write_page("services", page("AI Services | From Future",
        "Explore our comprehensive suite of AI solutions including voice agents, chatbots, AI SEO, and process automation.", body,
        canonical="https://www.fromfuture.io/services"))

# ---------------- tap-to-talk ----------------
def build_tap_to_talk():
    body = page_hero("Tap-to-Talk AI Agent", 'Transform Your Website with <span class="grad-text">AI Voice</span>',
        "Give your visitors the future of customer interaction &mdash; natural voice conversations that convert better than chat or forms.",
        '<a class="btn btn-primary" href="/connect">Book Your Free Demo</a>',
        extra="""<div class="demo-module rv rv-d3" style="margin-top:48px"><div style="flex:1">
          <label>Try Our Tap-To-Talk Assistant</label>
          <p style="color:var(--grey);font-size:14px">Tap the mic and speak with our live AI agent.</p></div>
          <fromfuture-convai agent-id="bAzQsMlkaQa8CHH2V7mr" style="position:static;margin:0 auto;z-index:1000"></fromfuture-convai></div>
          <script src="https://media.fromfuture.io/scripts/ttt-widget/ttt-8-beta.js" defer></script>
          <script src="https://media.fromfuture.io/scripts/ttt-widget/ttt-demo.js" defer></script>""")
    body += sec("Why It Works","Voice Converts <span class='grad-text'>3x Better</span>","",
      cards_grid([
        dict(title="3x Higher Conversion Rate", desc="Voice interactions convert 3x better than chatbots and forms. Customers prefer speaking naturally over typing."),
        dict(title="24/7 Availability", desc="Never miss an opportunity. Your AI voice assistant handles inquiries, books appointments, and qualifies leads around the clock."),
        dict(title="One-Click Setup", desc="Add voice AI to your site with a single line of code. We handle the complex tech so you can focus on growth."),
      ]))
    body += sec("The Numbers","Proof in <span class='grad-text'>Performance</span>","",
      stats([("70%","Reduction in Customer Service Costs"),("24/7","Always-On Lead Generation"),("5min","Average Setup Time")]))
    body += sec("Integration","Simple Integration, <span class='grad-text'>Powerful Results</span>","",
      steps([("One Line of Code","Add our voice widget to your site with a single line of code &mdash; no complex setup required."),
             ("Customized to Your Brand","Personalize the voice, appearance, and knowledge base to match your brand perfectly."),
             ("Start Converting","Watch as your voice AI assistant engages visitors and drives conversions 24/7.")])
      + """<div class="code-block rv">&lt;sistem-convai agent-id="your-agent-id"&gt;&lt;/sistem-convai&gt;<br>&lt;script src="https://scripts.sistem.ai/voice.js"&gt;&lt;/script&gt;</div>""")
    body += cta_section("Ready to See It In Action?",
        "Schedule a personalized demo and discover how voice AI can transform your business. Our experts will show you: custom voice and personality matching your brand, integration with your existing systems, and an ROI projection for your specific business.",
        "Book Your Free Demo")
    write_page("services/tap-to-talk", page("AI Voice Agents | Website Voice Chat | From Future | FromFuture.io",
        "Transform your website with AI voice agents that convert 3x better than traditional chatbots.", body,
        canonical="https://www.fromfuture.io/services/tap-to-talk"))

# ---------------- online reputation management ----------------
def build_orm():
    serp = """<div class="grid-2">
      <div class="rv"><h3 style="color:var(--grey-2);margin-bottom:18px">What people see now</h3><div class="serp bad">
        <div class="row">#1 &mdash; Negative News Article &mdash; YourName.com</div>
        <div class="row">#2 &mdash; Legal Issues Surround [Your Name] &mdash; News Site</div>
        <div class="row">#3 &mdash; Controversy at [Your Business] &mdash; Local Paper</div>
        <div class="row">#4 &mdash; Negative Blog Post About [Your Name]</div>
        <div class="row">#5 &mdash; Negative Article About [Your Business Name]</div></div></div>
      <div class="rv rv-d1"><h3 style="color:var(--tint);margin-bottom:18px">After our campaign</h3><div class="serp good">
        <div class="row">#1 &mdash; Your Professional Website</div>
        <div class="row">#2 &mdash; Your LinkedIn Profile</div>
        <div class="row">#3 &mdash; Industry Awards &amp; Recognition</div>
        <div class="row">#4 &mdash; Your Company's Official Site</div>
        <div class="row">#5 &mdash; Positive Press Coverage</div></div></div></div>"""
    losses = cards_grid([
      dict(title="Business &amp; Income", desc="Clients, customers, and opportunities slip away when they Google your name and see negative content. Every lost deal costs you money."),
      dict(title="Professional Credibility", desc="Your expertise and accomplishments are overshadowed by negative press. People judge you before they even meet you."),
      dict(title="Personal Stress", desc="The anxiety of knowing anyone can find that article about you is exhausting. It affects your confidence and relationships."),
      dict(title="Future Opportunities", desc="Job interviews, partnerships, and networking opportunities are lost when negative articles dominate your search results."),
    ], cols=2)
    process = steps([
      ("Reputation Audit","We analyze every negative article, review, and mention ranking for your name or business on Google's first 3 pages."),
      ("Content Strategy","We create and optimize positive content specifically designed to outrank the negative articles in Google search results."),
      ("Suppression Campaign","Using advanced SEO techniques, we systematically push negative content down in rankings until it's no longer visible."),
    ]) + '<div class="steps" style="grid-template-columns:1fr;margin-top:26px"><div class="step rv" style="counter-increment:none"><h3>Ongoing Protection</h3><p style="color:var(--grey);margin-top:12px;font-size:15px">We monitor your search results continuously to ensure negative content stays buried and your reputation remains protected.</p></div></div>'
    timeline = """<div class="grid-2" style="margin-top:40px">
      <div class="card rv"><h3>Week 1&ndash;2 &middot; Analysis &amp; Strategy</h3><p>Complete audit and content planning</p></div>
      <div class="card rv rv-d1"><h3>Month 1&ndash;3 &middot; Active Suppression</h3><p>Content creation and SEO optimization</p></div>
      <div class="card rv"><h3>Month 3&ndash;6 &middot; Results &amp; Refinement</h3><p>Negative content pushed off first page</p></div>
      <div class="card rv rv-d1"><h3>Ongoing &middot; Maintenance</h3><p>Continuous monitoring and protection</p></div></div>"""
    testis = cards_grid([
      dict(title="Sarah M.", stat="Marketing Executive", desc="&ldquo;That damaging article from 2019 was haunting my career prospects. From Future pushed it completely off the first page. Now when clients Google my name, they see my professional achievements instead.&rdquo;"),
      dict(title="Michael R.", stat="Restaurant Owner", desc="&ldquo;A false news story about our restaurant was killing our business. Within 3 months, it disappeared from Google's first page. Our bookings are back to normal and growing.&rdquo;"),
      dict(title="Jennifer L.", stat="Real Estate Agent", desc="&ldquo;I was losing potential clients because of negative press from a lawsuit that was later dismissed. Now those articles are buried and my business is thriving again.&rdquo;"),
    ])
    faq = accordion([
      ("How long does it take to see results?","Most clients see significant improvement within 3-6 months. The timeline depends on the authority of the negative content and the competitiveness of your name in search results."),
      ("Can you guarantee the negative content will be completely removed?","We specialize in suppression, not removal. We push negative content off the first page of Google where 95% of people stop searching. This is often more effective and sustainable than trying to remove content entirely."),
      ("What if new negative content appears?","Our ongoing monitoring service alerts us to new negative content immediately. We include protection against new threats as part of our maintenance service."),
      ("Do you work with both individuals and businesses?","Yes, we help both individual professionals and businesses dealing with negative articles, press coverage, legal records, or other damaging content in their search results."),
    ])
    body = page_hero("Online Reputation Management", 'Remove Negative Articles <span class="grad-text">from Google</span>',
        "That damaging article is destroying your reputation every time someone searches your name. We specialize in pushing negative content off Google's first page &mdash; permanently.",
        '<a class="btn btn-primary" href="/connect">Get Started Now</a>')
    body += sec("See The Problem?","Your Search Results, <span class='grad-text'>Before &amp; After</span>","",serp)
    body += sec("The Cost of Waiting","Every Day That Article Ranks, <span class='grad-text'>You're Losing...</span>","",losses)
    body += sec("How We Fix It","Our Reputation <span class='grad-text'>Recovery Process</span>","",process+timeline)
    body += sec("Track Record","The <span class='grad-text'>Results</span>","",
      stats([("98%","Success Rate in Suppressing Negative Content"),("3-6","Months Average to Push Content Off Page 1"),("100+","Professionals and Businesses Helped")]))
    body += sec("Client Stories","What Clients <span class='grad-text'>Say</span>","",testis)
    body += sec("Common Questions","Frequently Asked <span class='grad-text'>Questions</span>","",faq)
    body += cta_section("Don't Let Negative Articles Define You",
        "Every day you wait, that damaging content is costing you opportunities, relationships, and peace of mind. Let us help you take control of your online reputation.")
    write_page("services/online-reputation-management", page(
        "Online Reputation Management | Remove Negative Articles from Google | From Future | FromFuture.io",
        "Remove damaging negative articles from Google search results for your name or business.", body,
        canonical="https://www.fromfuture.io/services/online-reputation-management"))

# ---------------- page-speak ----------------
def build_pagespeak():
    how = steps([
      ("We Analyze Your Content","Our AI scans your website to understand your content structure, identify key pages, and prepare them for audio conversion."),
      ("We Convert to Audio","Using advanced 11Labs technology, we transform your content into natural-sounding audio in multiple languages of your choice."),
      ("We Integrate the Widget","Our team implements a customized audio player on your website, allowing visitors to listen to your content with a single click."),
    ]) + """<div class="center" style="margin-top:44px"><a class="btn btn-primary rv" href="https://portal.fromfuture.io/order/page-speak">Start Your Integration</a>
    <p class="rv" style="color:var(--grey-2);font-size:14px;margin-top:14px">One-time setup fee of $499, then pay only for the audio credits you use</p></div>"""
    feats = cards_grid([
      dict(title="Instant Audio Conversion", desc="Transform your written content into high-quality audio with a single click."),
      dict(title="Multilingual Support", desc="Offer your content in multiple languages with natural-sounding voices."),
      dict(title="Simple Integration", desc="Easy-to-implement widget that works seamlessly with any website platform."),
      dict(title="Accessibility Enhancement", desc="Make your content accessible to visually impaired users and those who prefer audio."),
      dict(title="Engagement Analytics", desc="Track how users interact with your audio content to optimize performance."),
      dict(title="Custom Voice Options", desc="Choose from a variety of natural-sounding voices to match your brand."),
    ])
    action = """<div class="cta-block rv"><div class="cta-grid"><div>
      <h3 style="font-size:24px;margin-bottom:16px">The Future of Content Consumption</h3>
      <p style="color:var(--grey)">In today's fast-paced digital world, content consumption habits are rapidly evolving. Users are increasingly looking for flexible ways to engage with online content that fit their busy lifestyles. Audio content provides the perfect solution, allowing users to consume information while commuting, exercising, or multitasking.</p>
      <p style="color:var(--grey);margin-top:14px">PageSpeak transforms your written content into high-quality audio, giving your audience the freedom to choose how they engage with your material. This not only improves accessibility but also significantly increases content consumption and time spent on your website.</p></div>
      <div class="session-card"><div class="eyebrow" style="margin-bottom:12px">Featured Article</div>
      <h3 style="font-size:16px">My Journey of Uploading My Mind to the Cloud to Become AI</h3>
      <p style="margin:10px 0 4px">Digital legacy that transcends time</p>
      <p class="micro">Kotton Grammer &middot; April 1, 2025 &middot; Pwrd by PageSpeak</p>
      <a class="btn btn-ghost" style="margin-top:20px" href="/blog/becoming-AI">Listen with PageSpeak</a></div></div></div>
      <!-- PAGESPEAK PLAYER: embed audio player + post selector here (11Labs audio; see README) -->"""
    why = """<ul class="cta-list rv" style="max-width:640px">
      <li>Increase content accessibility for all users</li><li>Boost engagement with audio alternatives</li>
      <li>Expand your audience to international markets</li><li>Improve SEO with longer site visits</li>
      <li>Enhance user experience with listening options</li></ul>
      <div style="margin-top:34px"><a class="btn btn-primary rv" href="https://portal.fromfuture.io/order/page-speak">Get PageSpeak</a></div>"""
    pricing = f"""<div class="grid-2">
      <div class="card price-card rv"><h3>One-Time Setup</h3><div class="amount">$499 <small>one-time fee</small></div>
        <ul><li>Full website integration</li><li>Custom widget styling</li><li>Initial content setup</li><li>Technical support</li></ul>
        <a class="btn btn-primary" href="https://portal.fromfuture.io/order/page-speak">Get Started with PageSpeak</a></div>
      <div class="card price-card rv rv-d1"><h3>Content Conversion Credits</h3><div class="amount">Pay once <small>per page</small></div>
        <p>Pay only when content is initially converted to audio. Once converted, your users can listen unlimited times at no additional cost.</p>
        <ul><li>One-time conversion fee per page</li><li>Unlimited listening after conversion</li><li>Volume discounts for larger sites</li></ul>
        <a class="btn btn-ghost" href="https://portal.fromfuture.io/order/page-speak">Purchase Now</a></div></div>
      <p class="center rv" style="color:var(--grey-2);font-size:14px;margin-top:26px">No long-term contracts. Cancel anytime.</p>"""
    faq = accordion([
      ("How does PageSpeak work?","PageSpeak uses advanced AI technology to convert your written content into natural-sounding audio. We integrate a simple widget on your website that allows visitors to listen to your content instead of reading it. The setup process is handled entirely by our team, requiring minimal effort from you."),
      ("What languages are supported?","PageSpeak supports over 30 languages including English, Spanish, French, German, Italian, Portuguese, Dutch, Japanese, Korean, Chinese, Arabic, and many more. We're constantly adding new languages to our platform."),
      ("How much content can I convert to audio?","Your usage is based on a credit system. After the initial setup fee, you only pay for what you use. Each credit allows for approximately 1,000 words of text-to-speech conversion. You can purchase credits as needed, and we offer volume discounts for larger content libraries."),
      ("Can I customize the voice used for my content?","Yes! PageSpeak offers a variety of voice options across different languages, accents, and styles. You can select the voice that best represents your brand. For an additional fee, we also offer voice cloning technology that can create a digital version of your own voice."),
      ("How is the PageSpeak widget implemented on my website?","Implementation is simple. Our team handles the entire setup process. We provide a small JavaScript snippet that you or your developer can add to your website. The widget is designed to be lightweight and won't affect your site's performance or loading speed."),
      ("Do I need technical knowledge to use PageSpeak?","Not at all. Our team handles the entire setup process, and the ongoing management is simple through our user-friendly dashboard. No coding or technical expertise is required."),
    ])
    clone = """<div class="cta-block rv"><div class="cta-grid"><div>
      <div class="eyebrow">Premium Add-on</div>
      <h2 class="grad-text" style="font-size:clamp(24px,3vw,40px)">Voice Cloning &mdash; The Ultimate Personalization</h2>
      <p class="lead" style="margin-top:18px">Let your audience hear content in your actual voice for a truly authentic experience.</p>
      <p style="color:var(--grey);margin-top:18px"><strong style="color:var(--white)">Your Voice, Your Brand.</strong> We walk the walk at From Future. Visit our blog and you'll hear content in the actual voice of each author &mdash; creating a personal connection that generic voices simply can't match.</p>
      <p style="color:var(--grey);margin-top:14px">After a simple 5-minute voice recording session, our AI creates a perfect digital replica of your voice to read your content.</p>
      <p class="quote">ROI Booster: Websites using personalized voice technology report 35% higher engagement and 28% longer visit durations.</p></div>
      <div class="session-card"><h3>$299 <span style="font-size:14px;color:var(--grey)">one-time setup</span></h3>
      <ul class="cta-list" style="text-align:left;margin:18px 0 24px">
        <li>Custom voice model creation</li><li>5-minute voice recording session</li>
        <li>Integration with your PageSpeak widget</li><li>Voice model updates (1x per year)</li></ul>
      <a class="btn btn-primary" href="https://portal.fromfuture.io/order/page-speak">Add Voice Cloning to Your Package</a>
      <p class="micro">Voice credits are billed at a 20% premium over standard voices, reflecting the enhanced personalization value.</p></div></div></div>"""
    body = page_hero("Introducing PageSpeak", 'Transform Your Content Into <span class="grad-text">Engaging Audio</span>',
        "Give your readers the option to listen to your content with our AI-powered audio conversion technology. Increase engagement, accessibility, and reach with natural-sounding voices in multiple languages.",
        '<a class="btn btn-primary" href="#discover">Discover PageSpeak</a>')
    body += sec("How It Works","How <span class='grad-text'>PageSpeak</span> Works","Transform your written content into engaging audio with our simple three-step process", how, id="discover")
    body += sec("Powerful Features","Everything You Need for <span class='grad-text'>Audio Experiences</span>","Everything you need to transform your content into engaging audio experiences", feats)
    body += sec("See It In Action","See PageSpeak <span class='grad-text'>in Action</span>","Experience how your content can sound with our AI-powered audio conversion", action)
    body += sec("Why PageSpeak","Why Choose <span class='grad-text'>PageSpeak?</span>","", why)
    body += sec("Pricing","Simple, Transparent <span class='grad-text'>Pricing</span>","One-time setup fee, then pay only for initial content conversion", pricing)
    body += sec("FAQ","Frequently Asked <span class='grad-text'>Questions</span>","Everything you need to know about PageSpeak",
        faq + '<div class="center" style="margin-top:36px"><p style="color:var(--grey);margin-bottom:18px">Have more questions? We\'re here to help.</p><a class="btn btn-ghost" href="/connect">Contact Our Team</a></div>')
    body += sec("Premium Add-on","Voice <span class='grad-text'>Cloning</span>","", clone)
    body += cta_section("Ready to Transform Your Content?",
        "Join the growing number of businesses enhancing their content with PageSpeak's audio conversion technology.",
        "Schedule a Demo", btn2=("Talk to an Expert","/connect"))
    write_page("services/page-speak", page("PageSpeak | AI Audio Content Conversion | From Future | FromFuture.io",
        "Transform your website content into engaging audio with PageSpeak. Our AI-powered solution converts blog posts and pages into natural-sounding audio in multiple languages.",
        body, canonical="https://www.fromfuture.io/services/page-speak"))

# ---------------- ai-seo ----------------
def build_aiseo():
    body = page_hero("AI Search Optimization (AIO)", 'Optimize for the <span class="grad-text">Future of Search</span>',
        "Don't just optimize for Google. Optimize for the future of search with AI-powered engines like Perplexity, ChatGPT, and Claude.",
        '<a class="btn btn-primary" href="/connect">Get Your Free Audit</a>')
    body += sec("The Shift Is Here","The <span class='grad-text'>Numbers</span>","",
        stats([("70%","of Gen Z uses AI search tools daily"),("3x","Higher visibility in AI search results"),("24/7","AI-optimized presence")]))
    body += sec("Why It Matters","Why AI Search Optimization <span class='grad-text'>Matters</span>","",
        cards_grid([
          dict(title="Beyond Traditional SEO", desc="AI search engines understand context and intent, not just keywords. We optimize your content for natural language understanding."),
          dict(title="Conversational Discovery", desc="Users are asking AI assistants for recommendations. We make sure your business is the answer they receive."),
          dict(title="Future-Proof Strategy", desc="Stay ahead of the curve as AI search engines become the primary way people find businesses online."),
        ]))
    chips = "".join(f'<span class="chip" style="font-size:13px;padding:16px 30px">{x}</span>' for x in
        ["Perplexity","ChatGPT","Google Gemini","Claude","Traditional Search Engines"])
    body += sec("Coverage","We Optimize <span class='grad-text'>For</span>","",
        f'<div class="rv" style="display:flex;gap:16px;flex-wrap:wrap">{chips}</div>')
    body += cta_section("Ready to Dominate AI Search?",
        "Get a free AI visibility audit and discover how we can optimize your business for the future of search.","Get Your Free Audit")
    write_page("services/ai-seo", page("AI Search Optimization (AIO) | Beyond Traditional SEO | From Future | FromFuture.io",
        "Optimize your business for AI-powered search engines like Perplexity, ChatGPT, and Claude. Get 3x higher visibility in AI search results and capture the next generation of customers who use AI for recommendations.",
        body, canonical="https://www.fromfuture.io/services/ai-seo"))

# ---------------- phone-ai ----------------
def build_phoneai():
    demo = """<div class="cta-block rv"><div class="cta-grid"><div>
      <h2 class="grad-text" style="font-size:clamp(24px,3vw,40px)">Experience Your Voice AI Assistant</h2>
      <p class="lead" style="margin-top:18px">Enter your details below and our AI will analyze your website, create a custom Voice Assistant, and call you within seconds.</p>
      <!-- PHONE-AI DEMO: wire this form to your voice-agent callback endpoint (see README) -->
      <form class="form-grid" style="margin-top:30px" data-ff-form>
        <input type="text" required placeholder="Name" aria-label="Name">
        <input type="url" required placeholder="Business Website" aria-label="Business Website">
        <input type="tel" required placeholder="Phone Number" aria-label="Phone Number">
        <button class="btn btn-primary" type="submit" style="justify-content:center">Start AI Call</button>
      </form></div>
      <div class="session-card"><div class="eyebrow" style="margin-bottom:14px">Your AI Phone Agent</div>
        <div style="font-family:var(--display);font-weight:800;font-size:30px;letter-spacing:.06em">(555) 123-4567</div>
        <p style="margin-top:12px">Available 24/7 for your customers</p></div></div></div>"""
    body = page_hero("Phone AI Assistant", 'AI Phone Agents That <span class="grad-text">Sound Human</span>',
        "Give your business a 24/7 phone presence with AI voice agents that handle calls, book appointments, and qualify leads &mdash; all while your team focuses on growth.",
        '<a class="btn btn-primary" href="/connect">Book Your Free Demo</a>')
    body += f'<section style="padding-top:0"><div class="wrap">{demo}</div></section>'
    body += sec("Why Us","Why Businesses Choose <span class='grad-text'>Our Phone AI</span>","",
        cards_grid([
          dict(title="Crystal Clear Calls", desc="Leverages phone's built-in noise cancellation for perfect clarity."),
          dict(title="24/7 Availability", desc="Never miss a call, even outside your business hours."),
          dict(title="Automated Booking", desc="Seamlessly schedule appointments and qualify leads automatically."),
        ]))
    body += sec("Impact","Transform Your <span class='grad-text'>Phone Operations</span>","",
        stats([("90%","Reduction in Missed Calls"),("75%","Cost Savings vs Live Agents"),("100%","Call Answer Rate")]))
    body += sec("Getting Started","Effortless Setup, <span class='grad-text'>Immediate Results</span>","",
        steps([("Get Your AI Number","Receive a dedicated phone number for your AI agent &mdash; ready to handle calls instantly."),
               ("Customize Your Agent","Train your AI with your business knowledge, services, and preferred responses."),
               ("Watch It Grow","Monitor calls, bookings, and leads in real-time through your dashboard.")]))
    body += cta_section("Experience the Future of Phone Support",
        "Try our AI phone agent yourself and see how it can transform your business communications. Perfect for high-call-volume businesses; handles appointments and lead qualification; seamless integration with your systems.",
        "Book Your Free Demo")
    write_page("services/phone-ai", page("AI Phone Agents & Virtual Receptionists | 24/7 Business Phone Support | FromFuture.io",
        "Transform your business phone system with AI voice agents that handle calls, schedule appointments, and qualify leads 24/7.",
        body, canonical="https://www.fromfuture.io/services/phone-ai"))

# ---------------- process automation ----------------
def build_automation():
    body = page_hero("Process Automation", 'AI Process <span class="grad-text">Automation</span>',
        "Discover how AI can automate your specific business processes. Enter your website below and we'll analyze your business to suggest custom automation opportunities.",
        extra="""<!-- ANALYZER: wire to your analysis endpoint (see README) -->
        <form class="form-grid rv rv-d2" style="margin-top:40px;grid-template-columns:1fr auto;max-width:560px" data-ff-form>
          <input type="url" required placeholder="https://yourwebsite.com" aria-label="Website URL">
          <button class="btn btn-primary" type="submit">Analyze</button></form>""")
    body += sec("Impact","Transform Your <span class='grad-text'>Business Operations</span>","",
        cards_grid([
          dict(title="Time-Saving Automation", desc="Automate repetitive tasks like data entry, appointment scheduling, and customer follow-ups, saving hours of manual work."),
          dict(title="Streamlined Workflows", desc="Create intelligent workflows that automatically route tasks, notify team members, and ensure nothing falls through the cracks."),
          dict(title="Smart Analytics", desc="Get real-time insights into your operations with automated reporting and intelligent analytics."),
        ]))
    chips = "".join(f'<span class="chip" style="font-size:13px;padding:16px 30px">{x}</span>' for x in
        ["Customer Support &amp; Inquiries","Appointment Scheduling","Document Processing","Email &amp; Communication","Data Entry &amp; Management"])
    body += sec("Scope","What We <span class='grad-text'>Automate</span>","",
        f'<div class="rv" style="display:flex;gap:16px;flex-wrap:wrap">{chips}</div>')
    body += sec("Solutions","Popular AI Automation <span class='grad-text'>Solutions</span>","",
        cards_grid([
          dict(title="Email Automation", desc="AI-powered email management that automatically categorizes, prioritizes, and responds to common inquiries.",
               features=["Smart response generation","Priority inbox management","Follow-up scheduling"]),
          dict(title="Document Processing", desc="Automated extraction and processing of information from documents, forms, and receipts.",
               features=["Data extraction &amp; entry","Document classification","Automated filing"]),
          dict(title="Customer Support", desc="24/7 automated customer support handling common questions and requests.",
               features=["Ticket categorization","Auto-response generation","Smart routing"]),
        ]))
    body += cta_section("Ready to Automate Your Business?",
        "Get a free automation assessment and discover how AI can transform your operations.","Start Automating Today")
    write_page("services/process-automation", page("AI Process Automation Solutions | Business Efficiency | From Future | FromFuture.io",
        "Transform your business operations with AI-powered process automation. Streamline workflows, reduce manual tasks, and improve efficiency with custom automation solutions for email management, document processing, customer support, and more.",
        body, canonical="https://www.fromfuture.io/services/process-automation"))

# ---------------- chatbot ----------------
def build_chatbot():
    body = page_hero("AI Chatbot", 'AI-Powered <span class="grad-text">Chatbots</span>',
        "Intelligent chatbots that understand context, provide instant support, and convert visitors into customers 24/7.",
        '<a class="btn btn-primary" href="/connect">Get Your Custom Chatbot</a>')
    body += sec("Impact","The <span class='grad-text'>Numbers</span>","",
        stats([("80%","Customer queries resolved automatically"),("5min","Average response time"),("24/7","Always-on support")]))
    body += sec("Different by Design","Not Just <span class='grad-text'>Another Chatbot</span>","",
        cards_grid([
          dict(title="Context-Aware Intelligence", desc="Our chatbots understand context and maintain conversation history, providing more natural and helpful interactions."),
          dict(title="Personalized Experience", desc="Adapts responses based on user behavior and preferences, creating engaging conversations that convert."),
          dict(title="Seamless Integration", desc="Integrates with your existing systems for appointment scheduling, CRM, and customer support tools."),
        ]))
    chips = "".join(f'<span class="chip" style="font-size:13px;padding:16px 30px">{x}</span>' for x in
        ["24/7 Customer Support","Appointment Scheduling","Lead Qualification","Product Recommendations","Human Handoff When Needed"])
    body += sec("Capabilities","Key <span class='grad-text'>Capabilities</span>","",
        f'<div class="rv" style="display:flex;gap:16px;flex-wrap:wrap">{chips}</div>')
    body += cta_section("Experience Our AI Chatbot",
        "Try our demo chatbot and see how it can transform your customer interactions.","Get Your Custom Chatbot")
    body += """<script src="https://media.fromfuture.io/scripts/ttt-widget/ttt-8-beta.js" defer></script>
<script src="https://media.fromfuture.io/scripts/ttt-widget/ttt-demo.js" defer></script>
<script src="https://media.fromfuture.io/scripts/tap-to-talk.js" defer></script>"""
    write_page("services/chatbot", page("AI Chatbots & Customer Support Automation | From Future | FromFuture.io",
        "Transform your customer support with AI-powered chatbots that understand context, provide 24/7 instant support, and convert visitors into customers.",
        body, canonical="https://www.fromfuture.io/services/chatbot"))

def build():
    build_index(); build_tap_to_talk(); build_orm(); build_pagespeak()
    build_aiseo(); build_phoneai(); build_automation(); build_chatbot()
