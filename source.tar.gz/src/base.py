# FROM FUTURE — shared page framework
ROOT = "/home/claude/fromfuture-site"
DIST = ROOT + "/dist"

GTM = "GTM-NFGP7XQD"

NAV = """
<header class="site-header"><div class="wrap nav-row">
  <a class="nav-logo" href="/" aria-label="From Future home"><img src="/assets/logo/fromfuture-lockup-white.png" alt="From Future"></a>
  <ul class="nav-links">
    <li><button type="button">Services <span class="caret"></span></button>
      <div class="dropdown">
        <a href="/services/tap-to-talk">Tap-to-Talk AI</a>
        <a href="/services/online-reputation-management">Online Reputation Management</a>
        <a href="/services/page-speak">PageSpeak</a>
        <a href="/services/ai-seo">AI SEO</a>
        <a href="/services/phone-ai">Phone AI Assistant</a>
        <a href="/services/process-automation">Process Automation</a>
        <a href="/services/chatbot">AI Chatbot</a>
      </div></li>
    <li><button type="button">Resources <span class="caret"></span></button>
      <div class="dropdown">
        <a href="https://network-6160969.mn.co" target="_blank" rel="noopener">Free AI Training</a>
        <a href="/blog">Blog</a>
        <a href="/resources/free-ai-resources">Free AI Resources</a>
      </div></li>
    <li><a href="/pricing">Pricing</a></li>
    <li><a href="/blog/becoming-AI">My AI Clone Story</a></li>
  </ul>
  <div class="nav-cta">
    <a class="portal-link" href="https://portal.fromfuture.io">Client Portal</a>
    <a class="btn btn-primary" href="/connect">Get Started Now</a>
    <button class="burger" aria-label="Menu"><span></span><span></span><span></span></button>
  </div>
</div></header>
"""

FOOTER = """
<footer><div class="wrap">
  <div class="foot-grid">
    <div class="foot-brand">
      <a href="/"><img src="/assets/logo/fromfuture-lockup-white.png" alt="From Future"></a>
      <p>From Future revolutionizes local businesses with customized AI voice and automation solutions for 24/7 customer engagement and operational efficiency.</p>
      <div class="foot-contact"><a href="mailto:support@fromfuture.io">support@fromfuture.io</a><br>Miami, FL, USA</div>
    </div>
    <div><h4>Company</h4><ul class="foot-links">
      <li><a href="/about">About</a></li><li><a href="/connect">Contact</a></li>
      <li><a href="/blog">Blog</a></li><li><a href="/careers">Careers</a></li></ul></div>
    <div><h4>Legal</h4><ul class="foot-links">
      <li><a href="/privacy">Privacy</a></li><li><a href="/terms">Terms</a></li></ul></div>
    <div><h4>Stay Updated</h4>
      <p style="color:var(--grey);font-size:14px;margin-bottom:18px">Get the latest AI insights and updates delivered to your inbox.</p>
      <form class="news-form" data-ff-form style="flex-direction:column;gap:10px;display:flex">
        <input type="text" placeholder="Your name" aria-label="Name" style="border-radius:9999px;border-right:1px solid hsl(var(--foreground) / .12)">
        <div style="display:flex"><input type="email" required placeholder="Enter your email" aria-label="Email"><button type="submit">Subscribe</button></div>
      </form>
      <label class="agency-check"><input type="checkbox"> I represent a digital marketing agency</label>
    </div>
  </div>
  <div class="foot-bottom">
    <div>&copy; 2026 From Future. All rights reserved.</div>
    <a href="https://www.linkedin.com/company/from-future-agency" target="_blank" rel="noopener">LinkedIn</a>
  </div>
</div></footer>
<script src="/assets/site.js"></script>
"""

def page(title, desc, body, canonical=None, og_image="https://fromfuture.io/assets/media/og-card.png", noindex=False, extra_head="", extra_js=""):
    canon = f'<link rel="canonical" href="{canonical}">' if canonical else ""
    robots = '<meta name="robots" content="noindex">' if noindex else '<meta name="robots" content="index, follow">'
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
{robots}{canon}
<meta name="theme-color" content="#C154F8">
<meta property="og:title" content="{title}"><meta property="og:description" content="{desc}">
<meta property="og:image" content="{og_image}"><meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" sizes="32x32" href="/assets/icons/favicon-32.png">
<link rel="icon" sizes="64x64" href="/assets/icons/favicon-64.png">
<link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon-180.png">
<link rel="preload" as="font" type="font/woff2" href="/assets/fonts/geist-sans-latin-400-normal.woff2" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="/assets/fonts/geist-sans-latin-500-normal.woff2" crossorigin>
<link href="https://api.fontshare.com/v2/css?f[]=general-sans@400,500,600,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/theme.css">
<script async src="https://static.klaviyo.com/onsite/js/klaviyo.js?company_id=TTxeHT"></script>
<!-- Meta Pixel -->
<script>!function(f,b,e,v,n,t,s){{if(f.fbq)return;n=f.fbq=function(){{n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)}};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','551103760643973');fbq('track','PageView');</script>
{extra_head}
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){{w[l]=w[l]||[];w[l].push({{'gtm.start':new Date().getTime(),event:'gtm.js'}});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);}})(window,document,'script','dataLayer','{GTM}');</script>
</head>
<body>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id={GTM}" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
{NAV}
<main>
{body}
</main>
{FOOTER}
{extra_js}
</body></html>"""

import os
def write_page(path, html):
    """path like '' , 'pricing', 'services/tap-to-talk' -> dist/<path>/index.html"""
    d = os.path.join(DIST, path) if path else DIST
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "index.html"), "w") as f:
        f.write(html)

def page_hero(eyebrow, h1, lead=None, ctas=None, extra=""):
    lead_html = f'<p class="lead rv rv-d1">{lead}</p>' if lead else ""
    ctas_html = f'<div class="hero-ctas rv rv-d2">{ctas}</div>' if ctas else ""
    return f"""<section class="page-hero"><div class="wrap">
      <div class="eyebrow rv">{eyebrow}</div>
      <h1 class="rv">{h1}</h1>
      {lead_html}{ctas_html}{extra}
    </div></section>"""

def cta_section(h2="Ready to Transform Your Business?", body=None, btn_label="Schedule a Strategy Session", btn_href="/connect", btn2=None):
    body = body or "Book your free strategy session today and discover how our AI solutions can revolutionize your customer experience and operations."
    b2 = f'<a class="btn btn-ghost" href="{btn2[1]}">{btn2[0]}</a>' if btn2 else ""
    return f"""<section><div class="wrap"><div class="cta-block rv"><div class="cta-grid"><div>
      <h2 class="grad-text">{h2}</h2>
      <p class="lead" style="margin-top:20px">{body}</p>
      </div><div class="session-card">
      <h3>Book Your Strategy Session</h3>
      <p>30-minute consultation with our AI specialists</p>
      <a class="btn btn-primary" href="{btn_href}">{btn_label}</a>
      {b2}
      <p class="micro">No commitment required</p>
      </div></div></div></div></section>"""

def cards_grid(cards, cols=3):
    """cards: list of dict(title, desc, features(list), href, badge, icon_svg, stat)"""
    out = [f'<div class="grid-{cols}">']
    for i, c in enumerate(cards):
        badge = f'<div class="badge{" soon" if c.get("soon") else ""}">{c["badge"]}</div>' if c.get("badge") else ""
        feats = ""
        if c.get("features"):
            feats = "<ul>" + "".join(f"<li>{f}</li>" for f in c["features"]) + "</ul>"
        learn = f'<a class="learn" href="{c["href"]}">Learn more <span class="arrow">→</span></a>' if c.get("href") else ""
        stat = f'<div style="font-family:var(--display);font-weight:700;color:var(--tint);font-size:13px;letter-spacing:.08em;margin-bottom:10px">{c["stat"]}</div>' if c.get("stat") else ""
        out.append(f"""<div class="card rv rv-d{i%3}">{badge}
          <h3>{c["title"]}</h3>{stat}<p>{c["desc"]}</p>{feats}{learn}</div>""")
    out.append("</div>")
    return "".join(out)
