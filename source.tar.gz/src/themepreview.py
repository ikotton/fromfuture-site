# THEME PREVIEW — /theme-preview
# From Future's structure and links rendered in the client-supplied spec:
# deep dark blue-purple (260 87% 3%), Geist Sans body, General Sans display,
# JS fade-looped background video, blurred overlay shape, liquid-glass, marquee.
from base import write_page

VIDEO = "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260328_065045_c44942da-53c6-4804-b734-f9e07fc22e08.mp4"

# marquee entries: real industry pages (structure/links preserved), not template logos
MARQUEE = [
    ("Legal Services", "/solutions/voice-ai/legal-services"),
    ("Real Estate", "/solutions/voice-ai/real-estate"),
    ("Dental Care", "/solutions/voice-ai/dental-care"),
    ("Restaurants", "/solutions/voice-ai/restaurants"),
    ("Roofing", "/solutions/voice-ai/roofing"),
    ("HVAC", "/solutions/voice-ai/hvac"),
]

CHEV = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="opacity:.7"><path d="m6 9 6 6 6-6"/></svg>'


def marquee_items():
    out = []
    for name, href in MARQUEE:
        out.append(f'''<a class="mq-item" href="{href}">
          <span class="liquid-glass mq-ic">{name[0]}</span>
          <span class="mq-name">{name}</span></a>''')
    return "".join(out)


def build():
    items = marquee_items()
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Theme Preview | From Future</title>
<meta name="robots" content="noindex">
<link rel="icon" sizes="32x32" href="/assets/icons/favicon-32.png">
<link rel="preconnect" href="https://d8j0ntlcm91z4.cloudfront.net" crossorigin>
<link href="https://api.fontshare.com/v2/css?f[]=general-sans@400,500,600,700&display=swap" rel="stylesheet">
<style>
/* ---- Geist Sans (self-hosted) ---- */
@font-face{{font-family:'Geist Sans';src:url('/assets/fonts/geist-sans-latin-400-normal.woff2') format('woff2');font-weight:400;font-display:swap}}
@font-face{{font-family:'Geist Sans';src:url('/assets/fonts/geist-sans-latin-500-normal.woff2') format('woff2');font-weight:500;font-display:swap}}
@font-face{{font-family:'Geist Sans';src:url('/assets/fonts/geist-sans-latin-600-normal.woff2') format('woff2');font-weight:600;font-display:swap}}

/* ---- theme tokens (per spec) ---- */
:root{{
  --background:260 87% 3%;
  --foreground:40 6% 95%;
  --hero-sub:40 6% 82%;
}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{
  background:hsl(var(--background));
  color:hsl(var(--foreground));
  font-family:'Geist Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  -webkit-font-smoothing:antialiased;
}}
a{{color:inherit;text-decoration:none}}
button{{font-family:inherit;cursor:pointer}}

/* ---- liquid glass (verbatim from spec) ---- */
.liquid-glass{{
  background:rgba(255,255,255,0.01);
  background-blend-mode:luminosity;
  backdrop-filter:blur(4px);
  border:none;
  box-shadow:inset 0 1px 1px rgba(255,255,255,0.1);
  position:relative;
  overflow:hidden;
}}
.liquid-glass::before{{
  content:"";position:absolute;inset:0;border-radius:inherit;padding:1.4px;
  background:linear-gradient(180deg,rgba(255,255,255,0.45) 0%,rgba(255,255,255,0.15) 20%,rgba(255,255,255,0) 40%,rgba(255,255,255,0) 60%,rgba(255,255,255,0.15) 80%,rgba(255,255,255,0.45) 100%);
  -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);
  -webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none;
}}

/* ---- page wrapper: video behind everything ---- */
.wrapper{{position:relative;overflow:hidden;min-height:100vh}}
.bg-video{{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0}}
.content{{position:relative;z-index:10}}

/* ---- hero section: min-h-screen flex-col ---- */
.hero-sec{{min-height:100vh;display:flex;flex-direction:column;overflow:visible;position:relative}}

/* blurred overlay shape */
.blur-shape{{
  width:984px;height:527px;opacity:.9;background:#030712;filter:blur(82px);
  position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  pointer-events:none;
}}

/* ---- navbar ---- */
nav{{width:100%;padding:20px 32px;display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;z-index:20}}
nav .logo img{{height:32px;width:auto;display:block}}
.nav-center{{display:flex;align-items:center;gap:8px}}
.nav-center>div{{position:relative}}
.nav-btn{{display:inline-flex;align-items:center;gap:6px;background:none;border:none;
  color:hsl(var(--foreground) / .9);font-size:15px;font-weight:500;padding:10px 14px;border-radius:8px;
  transition:color .25s,background .25s}}
.nav-btn:hover{{color:hsl(var(--foreground));background:rgba(255,255,255,.05)}}
.dd{{position:absolute;top:calc(100% + 8px);left:0;min-width:260px;border-radius:14px;padding:8px;
  background:rgba(8,4,18,.92);backdrop-filter:blur(20px);
  box-shadow:inset 0 1px 1px rgba(255,255,255,.1),0 30px 60px rgba(0,0,0,.55);
  opacity:0;visibility:hidden;transform:translateY(6px);transition:all .3s ease;z-index:30}}
.nav-center div:hover>.dd,.nav-center div:focus-within>.dd{{opacity:1;visibility:visible;transform:translateY(0)}}
.dd a{{display:block;padding:10px 14px;border-radius:8px;font-size:14px;color:hsl(var(--foreground) / .8)}}
.dd a:hover{{background:rgba(255,255,255,.06);color:hsl(var(--foreground))}}
.nav-right{{display:flex;align-items:center;gap:10px}}
.btn-hero-secondary{{
  border-radius:9999px;padding:8px 16px;font-size:14px;font-weight:500;
  color:hsl(var(--foreground));border:none;display:inline-flex;align-items:center;
  transition:transform .25s ease,box-shadow .25s ease}}
.btn-hero-secondary:hover{{transform:translateY(-1px);box-shadow:inset 0 1px 1px rgba(255,255,255,.18),0 6px 24px rgba(0,0,0,.35)}}
.divider{{height:1px;margin-top:3px;background:linear-gradient(to right,transparent,hsl(var(--foreground) / .2),transparent)}}

/* ---- hero content ---- */
.hero-mid{{flex:1;display:flex;align-items:center;justify-content:center;position:relative}}
.hero-inner{{text-align:center;position:relative;z-index:10;padding:0 24px}}
.headline{{
  font-family:'General Sans','Geist Sans',sans-serif;
  font-size:min(220px,14.5vw);
  font-weight:400;line-height:1.02;letter-spacing:-0.024em;
  color:hsl(var(--foreground));white-space:nowrap}}
.headline .grad{{
  background-image:linear-gradient(to left,#6366f1,#a855f7,#fcd34d);
  -webkit-background-clip:text;background-clip:text;color:transparent}}
.subtitle{{
  color:hsl(var(--hero-sub));font-size:18px;line-height:2rem;max-width:28rem;
  margin:9px auto 0;opacity:.8}}
.cta{{margin-top:25px;padding:24px 29px;font-size:16px;border-radius:9999px}}

/* ---- logo marquee ---- */
.mq-band{{padding-bottom:40px;position:relative;z-index:10}}
.mq-wrap{{max-width:64rem;margin:0 auto;display:flex;align-items:center;gap:48px;padding:0 24px}}
.mq-label{{color:hsl(var(--foreground) / .5);font-size:14px;line-height:1.5;flex:0 0 auto}}
.mq-viewport{{overflow:hidden;flex:1;-webkit-mask-image:linear-gradient(to right,transparent,#000 8%,#000 92%,transparent);mask-image:linear-gradient(to right,transparent,#000 8%,#000 92%,transparent)}}
.mq-track{{display:flex;gap:64px;width:max-content;animation:mq 20s linear infinite}}
@keyframes mq{{from{{transform:translateX(0%)}}to{{transform:translateX(-50%)}}}}
.mq-item{{display:flex;align-items:center;gap:12px;flex:0 0 auto}}
.mq-ic{{width:24px;height:24px;border-radius:8px;display:inline-flex;align-items:center;justify-content:center;
  font-size:12px;font-weight:600;color:hsl(var(--foreground) / .9)}}
.mq-name{{font-size:16px;font-weight:600;color:hsl(var(--foreground))}}

@media(max-width:900px){{
  .nav-center{{display:none}}
  .headline{{white-space:normal;font-size:clamp(56px,16vw,120px)}}
  .blur-shape{{width:120vw;height:60vh}}
  .mq-wrap{{flex-direction:column;gap:24px;text-align:center}}
}}
</style>
</head>
<body>
<div class="wrapper">
  <video class="bg-video" id="bgv" muted playsinline preload="auto" src="{VIDEO}"></video>

  <div class="content">
    <section class="hero-sec">
      <div class="blur-shape"></div>

      <nav>
        <a class="logo" href="/"><img src="/assets/logo/fromfuture-lockup-white.png" alt="From Future"></a>
        <div class="nav-center">
          <div><a class="nav-btn" href="/services">Services {CHEV}</a>
            <div class="dd">
              <a href="/services/tap-to-talk">Tap-to-Talk AI</a>
              <a href="/services/online-reputation-management">Online Reputation Management</a>
              <a href="/services/page-speak">PageSpeak</a>
              <a href="/services/ai-seo">AI SEO</a>
              <a href="/services/phone-ai">Phone AI Assistant</a>
              <a href="/services/process-automation">Process Automation</a>
              <a href="/services/chatbot">AI Chatbot</a>
            </div></div>
          <div><a class="nav-btn" href="/resources">Resources {CHEV}</a>
            <div class="dd">
              <a href="https://network-6160969.mn.co" target="_blank" rel="noopener">Free AI Training</a>
              <a href="/blog">Blog</a>
              <a href="/resources/free-ai-resources">Free AI Resources</a>
            </div></div>
          <div><a class="nav-btn" href="/pricing">Pricing</a></div>
          <div><a class="nav-btn" href="/blog/becoming-AI">My AI Clone Story</a></div>
        </div>
        <div class="nav-right">
          <a class="btn-hero-secondary liquid-glass" href="https://portal.fromfuture.io">Client Portal</a>
          <a class="btn-hero-secondary liquid-glass" href="/connect">Get Started Now</a>
        </div>
      </nav>
      <div class="divider"></div>

      <div class="hero-mid">
        <div class="hero-inner">
          <h1 class="headline">From <span class="grad">Future</span></h1>
          <p class="subtitle">Stop being the bottleneck in your own business. We capture your exact voice, tone, and business rules into a custom AI engine that answers your phones, replies to DMs, handles emails, and books appointments on autopilot.</p>
          <a class="btn-hero-secondary liquid-glass cta" href="/connect">Book a Systems Audit</a>
        </div>
      </div>

      <div class="mq-band">
        <div class="mq-wrap">
          <div class="mq-label">Relied on by businesses<br>across the globe</div>
          <div class="mq-viewport">
            <div class="mq-track">{items}{items}</div>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>

<script>
/* Custom fade loop per spec: 0.5s fade-in at start, 0.5s fade-out at end,
   requestAnimationFrame-driven. On ended: opacity to 0, wait 100ms, replay. */
(function () {{
  var v = document.getElementById('bgv');
  var FADE = 0.5, raf = null;

  function tick() {{
    if (!v.duration) {{ raf = requestAnimationFrame(tick); return; }}
    var t = v.currentTime, d = v.duration;
    var o = Math.min(t / FADE, (d - t) / FADE, 1);
    v.style.opacity = Math.max(0, Math.min(1, o)).toFixed(3);
    raf = requestAnimationFrame(tick);
  }}

  v.addEventListener('play', function () {{
    if (raf) cancelAnimationFrame(raf);
    raf = requestAnimationFrame(tick);
  }});

  v.addEventListener('ended', function () {{
    if (raf) cancelAnimationFrame(raf);
    v.style.opacity = 0;
    setTimeout(function () {{
      v.currentTime = 0;
      v.play().catch(function () {{}});
    }}, 100);
  }});

  v.play().catch(function () {{
    /* autoplay blocked: retry on first interaction */
    var kick = function () {{ v.play().catch(function () {{}}); document.removeEventListener('click', kick); }};
    document.addEventListener('click', kick);
  }});
}})();
</script>
</body></html>"""
    write_page("theme-preview", html)
