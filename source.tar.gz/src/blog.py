from base import page, write_page, page_hero
import os, re
import markdown as md

ROOT = "/home/claude/fromfuture-site"
BLOGDIR = ROOT + "/content/blog"

# canonical ordering + metadata (slug, date shown, tag override)
ORDER = [
 ("becoming-AI","Apr 1, 2025"),
 ("the-ai-search-revolution-is-here-and-it-s-wild","Mar 17, 2025"),
 ("phone-problems-wrecking-your-business-voice-ai-by-from-future-saves-dentists-plumbers-and-restaurants","Mar 16, 2025"),
 ("how-voice-ai-is-transforming-chiropractic-offices-and-why-it-s-essential-for-your-practice","Mar 15, 2025"),
 ("how-voice-ai-is-revolutionizing-the-plumbing-industry-and-why-it-s-the-future","Mar 15, 2025"),
 ("7-myths-about-artificial-intelligence-you-probably-believe-and-why-they-re-totally-wrong","Mar 14, 2025"),
 ("the-future-is-now-5-revolutionary-ai-medical-breakthroughs-coming-in-the-next-5-years","Mar 14, 2025"),
 ("bestAIwriters","Feb 28, 2025"),
 ("ChatGPTSoundMoreNatural","Feb 28, 2025"),
 ("ai-seo-vs-traditional-seo-what-businesses-need-to-know","Feb 26, 2025"),
 ("7-industries-being-transformed-by-conversational-ai","Feb 26, 2025"),
 ("ChatGPT","Feb 26, 2025"),
 ("automating-business-processes-where-to-start-with-ai","Feb 26, 2025"),
 ("the-dark-side-of-ai-ethical-considerations-for-businesses","Feb 26, 2025"),
 ("how-voice-ai-is-revolutionizing-customer-service-in-2025","Feb 26, 2025"),
 ("ai-for-small-businesses-affordable-implementation-strategies","Feb 26, 2025"),
]

CTA = """<div class="cta-block rv" style="margin-top:70px"><div class="cta-grid"><div>
  <h2 class="grad-text" style="font-size:clamp(22px,2.6vw,34px)">Ready to Transform Your Business with AI?</h2>
  <p class="lead" style="margin-top:16px">Book a free 30-minute strategy session with our AI specialists to discover how voice AI can revolutionize your customer interactions.</p></div>
  <div class="session-card"><a class="btn btn-primary" href="/connect">Schedule Your Free Consultation</a></div></div></div>"""

def parse(slug):
    path = os.path.join(BLOGDIR, slug + ".md")
    raw = open(path).read()
    meta = {}
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", raw, flags=re.S)
    body = raw
    if m:
        body = raw[m.end():]
        for line in m.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                v = v.strip().strip('"')
                if k.strip() == "tags":
                    v = [t.strip().strip('"').strip("'") for t in v.strip("[]").split(",") if t.strip()]
                meta[k.strip()] = v
    # drop duplicated H1 at top (frontmatter title is used)
    body = re.sub(r"^\s*# .*?\n", "", body, count=1)
    return meta, body

def build():
    cards = []
    for i, (slug, date) in enumerate(ORDER):
        meta, body = parse(slug)
        title = meta.get("title", slug)
        author = meta.get("author", "Kotton Grammer")
        tags = meta.get("tags", []) or []
        excerpt = meta.get("excerpt", "")
        tag_html = "".join(f'<span class="tag-pill">{t}</span>' for t in tags)

        html_body = md.markdown(body, extensions=["tables"])
        post = page_hero("From Future Blog", title,
            extra=f'<div class="post-meta rv rv-d1">{tag_html}<span>{author}</span><span>&middot;</span><span>{date}</span></div>')
        post += f'<section style="padding-top:0"><div class="wrap"><div class="prose rv">{html_body}</div><div class="wrap">{CTA}</div></div></section>'
        write_page(f"blog/{slug}", page(f"{title} | From Future Blog",
            excerpt or title, post, canonical=f"https://www.fromfuture.io/blog/{slug}"))

        ex = f"<p>{excerpt}</p>" if excerpt else ""
        cards.append(f"""<a class="card rv rv-d{i%3}" href="/blog/{slug}" style="display:flex;flex-direction:column">
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">{tag_html}</div>
          <h3 style="font-size:17px">{title}</h3>{ex}
          <div class="post-meta" style="margin-top:auto;padding-top:18px">{author} &middot; {date}</div></a>""")

    body = page_hero("The Blog", 'Insights from <span class="grad-text">the Future</span>',
        "Insights on AI technology, voice assistants, and digital innovation.")
    body += f'<section style="padding-top:0"><div class="wrap"><div class="grid-3">{"".join(cards)}</div></div></section>'
    write_page("blog", page("From Future Blog - Insights on AI Technology, Voice Assistants, and Digital Innovation",
        "Explore our latest articles, guides, and insights on AI technology and solutions.",
        body, canonical="https://www.fromfuture.io/blog"))
